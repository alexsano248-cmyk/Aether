# Aether Client (Fabric 1.21.1)

Rebrand of Zoomies + new modules. Built for Minecraft **1.21.1** (Fabric loader 0.16.x, Java 21).
Pojav / Zalith / PC compatible.

## What changed vs original

- Rebrand `Zoomies` → `Aether` (package `net.aether.aether`, mod id `aether`, assets, mixin config).
- **Removed modules**: FastXP, TestModule, Prevent, PearlMacro, ShieldBoost, CW, MouseTaper, AnchorMacro, AntiPowderSnow.
- **Renamed modules**: `HUDEnabler` → `HUD`, `ModulesList` → `ArrayList`.
- **Sprint**: new `Mode` setting `Normal` / `Omni`. `Omni` boosts movement speed attribute by `Omni Boost` (default +0.5x).
- **New modules** added (all `net.aether.aether.module.modules.*`):
  - `KillAura` (Combat) — Single / Switch / Multi, range, CPS, players/mobs/invisible filters.
  - `Scaffold` (World) — auto-place beneath; rotation None/Normal/OmniPred.
  - `LagRange` (Combat) — packet-hold lagback within configured range.
  - `AutoRecraft` (Player) — preset stub (Totem / Crystal / Gapple / Custom).
  - `AutoSoup` (Player) — auto-eat at configurable HP.
  - `Camera` (Render) — First / Third / ThirdFront.
  - `BowAimbot` (Combat) — auto-aim closest player while drawing a bow.
  - `ChinaHat` (Render) — cosmetic cone (size / height settings).
  - `Watermark` (Render) — top-left tag, font / color / shadow / show FPS / show user.
  - `TargetHUD` (Render) — HP bar + skin head when KillAura has a target.

## Build

```bash
# Requires JDK 21
./gradlew build
# Output: build/libs/aether-1.0.0.jar
```

Drop the jar in `<mc>/mods/` alongside `fabric-api-*.jar`.

## Multi-version (1.21 → 1.21.5)

The source targets 1.21.1. To build for another 1.21.x, edit `gradle.properties`:

```
minecraft_version=1.21.X
loader_version=<from fabricmc.net/develop>
fabric_version=<from fabricmc.net/develop>
```

Intermediary field/method names are stable across the 1.21.x line in most cases, but expect
1-2 references to break when crossing minor versions. Fix any "cannot find symbol" by looking
up the new intermediary name at https://linkie.shedaniel.dev/.

## Honest disclaimers

- Sources are decompiled (Vineflower) with intermediary names — Loom is configured to use
  intermediary as the workspace mapping so it compiles unchanged. If you prefer Yarn/Mojang
  mappings, run `./gradlew migrateMappings` or remap manually.
- New modules are minimal but functional. `AutoRecraft` is a stub (registers + toggles cleanly,
  no real crafting logic yet). `ChinaHat` registers but its 3D cone draw needs a WorldRenderEvent
  listener you can wire in `WorldRenderEvents.AFTER_ENTITIES`.
- Pojav/Zalith: requires Java 21 runtime (Zalith ≥ 1.5 / PojavLauncher Pro recent build).
