package net.aether.aether.command.commands;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import java.util.List;
import net.aether.aether.command.Command;
import net.aether.aether.command.CommandManager;
import net.aether.aether.util.ChatUtils;
import net.aether.aether.util.ColorUtils;
import net.minecraft.class_2172;

public class Help extends Command {
   private static final int COMMANDS_PER_PAGE = 5;

   public Help() {
      super("help", "Lists all commands with pagination");
   }

   @Override
   public void build(LiteralArgumentBuilder<class_2172> builder) {
      ((LiteralArgumentBuilder)builder.then(RequiredArgumentBuilder.argument("page", IntegerArgumentType.integer(1)).executes(context -> {
         int page = IntegerArgumentType.getInteger(context, "page");
         this.showHelpPage(page);
         return this.SINGLE_SUCCESS;
      }))).executes(context -> {
         this.showHelpPage(1);
         return this.SINGLE_SUCCESS;
      });
   }

   private void showHelpPage(int page) {
      List<Command> commands = CommandManager.get().getAll();
      int totalPages = (int)Math.ceil((double)commands.size() / 5.0);
      page = Math.max(1, Math.min(page, totalPages));
      ChatUtils.clearChat();
      int start = (page - 1) * 5;
      int end = Math.min(start + 5, commands.size());
      ChatUtils.sendMsg(ColorUtils.aqua + "---- Aether Help [" + page + "/" + totalPages + "] ----");

      for (Command cmd : commands.subList(start, end)) {
         ChatUtils.sendMsg(ColorUtils.aqua + cmd.getName() + ColorUtils.white + " - " + cmd.getDescription());
      }

      ChatUtils.sendMsg(ColorUtils.green + "Use .help <page> to navigate");
   }
}
