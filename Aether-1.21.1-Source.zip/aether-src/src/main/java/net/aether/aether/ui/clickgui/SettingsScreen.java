package net.aether.aether.ui.clickgui;

import net.aether.aether.module.Module;
import net.aether.aether.module.settings.Setting;
import net.aether.aether.ui.SetScreenButton;
import net.aether.aether.ui.hud.editor.HUDEditorScreen;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class SettingsScreen extends class_437 {
   private Module module;
   private SetScreenButton backButton;
   private SetScreenButton editButton;
   private boolean dragging = false;
   private int startX;
   private int startY;
   private int x = ClickGUIScreen.INSTANCE.field_22789 / 2 - 112;
   private int y = ClickGUIScreen.INSTANCE.field_22790 / 2 - 96;
   private int windowWidth = 224;
   private int windowHeight = 192;

   public SettingsScreen(Module module) {
      super(class_2561.method_43470("Settings"));
      this.backButton = new SetScreenButton("< Back", this.x + 8, this.y + 8, 16777215, ClickGUIScreen.INSTANCE);
      this.editButton = new SetScreenButton("Edit", this.x + this.windowWidth - 28, this.y + 8, 16777215, HUDEditorScreen.INSTANCE);
      this.module = module;
   }

   public void method_25394(class_332 drawContext, int mouseX, int mouseY, float delta) {
      this.method_25420(drawContext, mouseX, mouseY, delta);
      if (this.dragging) {
         this.x = mouseX - this.startX;
         this.y = mouseY - this.startY;
      }

      int radius = 8;
      drawContext.method_25294(this.x + radius, this.y, this.x + this.windowWidth - radius, this.y + this.windowHeight, -14540254);
      drawContext.method_25294(this.x, this.y + radius, this.x + this.windowWidth, this.y + this.windowHeight - radius, -14540254);
      this.drawCircle(drawContext, this.x + radius, this.y + radius, radius, -14540254);
      this.drawCircle(drawContext, this.x + this.windowWidth - radius, this.y + radius, radius, -14540254);
      this.drawCircle(drawContext, this.x + radius, this.y + this.windowHeight - radius, radius, -14540254);
      this.drawCircle(drawContext, this.x + this.windowWidth - radius, this.y + this.windowHeight - radius, radius, -14540254);
      drawContext.method_25294(this.x + radius, this.y, this.x + this.windowWidth - radius, this.y + 16, -14540254);
      drawContext.method_25300(this.field_22793, this.module.name, this.x + this.windowWidth / 2, this.y + 4, 16777215);
      drawContext.method_51433(this.field_22793, this.module.description, this.x + 8, this.y + 24, 16777215, true);
      this.backButton.render(drawContext, this.field_22793, mouseX, mouseY, this.x + 4, this.y + 4);
      if (this.module.showEditButton) {
         this.editButton.render(drawContext, this.field_22793, mouseX, mouseY, this.x + this.windowWidth - 22, this.y + 4);
      }

      int yOffset = this.y + 40;

      for (Setting setting : this.module.settings) {
         setting.render(drawContext, this.x + 16, yOffset, mouseX, mouseY, this.field_22793);
         yOffset += 25;
      }
   }

   private void drawCircle(class_332 drawContext, int centerX, int centerY, int radius, int color) {
      for (int y = -radius; y <= radius; y++) {
         for (int x = -radius; x <= radius; x++) {
            if (x * x + y * y <= radius * radius) {
               drawContext.method_25294(centerX + x, centerY + y, centerX + x + 1, centerY + y + 1, color);
            }
         }
      }
   }

   public boolean barHovered(int mouseX, int mouseY) {
      return mouseX >= this.x && mouseX <= this.x + this.windowWidth && mouseY >= this.y && mouseY <= this.y + 16;
   }

   public boolean method_25421() {
      return false;
   }

   public boolean method_25402(double mouseX, double mouseY, int button) {
      if (this.barHovered((int)mouseX, (int)mouseY)) {
         this.startX = (int)mouseX - this.x;
         this.startY = (int)mouseY - this.y;
         this.dragging = true;
      }

      this.backButton.mouseClicked((int)mouseX, (int)mouseY);
      this.editButton.mouseClicked((int)mouseX, (int)mouseY);

      for (Setting setting : this.module.settings) {
         setting.mouseClicked(mouseX, mouseY, button);
      }

      return super.method_25402(mouseX, mouseY, button);
   }

   public boolean method_25406(double mouseX, double mouseY, int button) {
      this.dragging = false;

      for (Setting setting : this.module.settings) {
         setting.mouseReleased(mouseX, mouseY, button);
      }

      return super.method_25406(mouseX, mouseY, button);
   }

   public boolean method_25404(int keyCode, int scanCode, int modifiers) {
      for (Setting setting : this.module.settings) {
         setting.keyPressed(keyCode, scanCode, modifiers);
      }

      return super.method_25404(keyCode, scanCode, modifiers);
   }

   public void method_25419() {
      class_310.method_1551().method_1507(ClickGUIScreen.INSTANCE);
   }
}
