package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;

public class ESP extends Module {
   public ESP() {
      super("ESP", "Lets you see entities through walls", Category.RENDER, true);
   }

   @Override
   public void onEnable() {
      super.onEnable();
   }

   @Override
   public void onDisable() {
      super.onDisable();
   }
}
