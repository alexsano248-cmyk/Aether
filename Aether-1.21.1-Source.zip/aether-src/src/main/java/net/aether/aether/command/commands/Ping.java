package net.aether.aether.command.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.aether.aether.command.Command;
import net.aether.aether.util.ChatUtils;
import net.aether.aether.util.ColorUtils;
import net.minecraft.class_2172;
import net.minecraft.class_310;

public class Ping extends Command {
   public Ping() {
      super("ping", "Gets your ping.");
   }

   @Override
   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.executes(
         context -> {
            if (class_310.method_1551().method_1558() == null) {
               ChatUtils.sendMsg(ColorUtils.red + "Not connected to a server.");
               return this.SINGLE_SUCCESS;
            } else {
               ChatUtils.sendMsg(
                  ColorUtils.aqua
                     + "Ping: "
                     + ColorUtils.white
                     + (
                        mc.method_1562().method_2871(mc.field_1724.method_5667()) == null
                           ? 0
                           : mc.method_1562().method_2871(mc.field_1724.method_5667()).method_2959()
                     )
               );
               return this.SINGLE_SUCCESS;
            }
         }
      );
   }
}
