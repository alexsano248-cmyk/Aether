package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;

public class AutoJReset extends Module {
   public AutoJReset() {
      super("AutoJumpReset", "Automatically jump resets to take less kb legit.", Category.COMBAT, true);
   }

   @Override
   public void tick() {
      if (mc.field_1724.field_6235 > 0 && mc.field_1724 != null && mc.field_1724.method_24828()) {
         mc.field_1724.method_6043();
      }
   }
}
