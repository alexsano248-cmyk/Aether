package net.aether.aether.module;

public enum Category {
   COMBAT("Combat", -43691),
   MOVEMENT("Movement", -43521),
   RENDER("Render", -11184641),
   WORLD("World", -11141291),
   PLAYER("Player", -16733526),
   CHAT("Chat", -22016),
   SPECIAL("Special", -1);

   public String name;
   public int color;

   private Category(String name, int color) {
      this.name = name;
      this.color = color;
   }
}
