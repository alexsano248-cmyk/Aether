package net.aether.aether.module.settings;

import net.minecraft.class_327;
import net.minecraft.class_332;

public class DropdownSetting extends Setting {
   public String value;
   public final String[] options;

   public DropdownSetting(String name, String defaultValue, String[] options) {
      this.name = name;
      this.value = defaultValue;
      this.options = options;
   }

   public void setValue(String value) {
      for (String option : this.options) {
         if (option.equals(value)) {
            this.value = value;
            break;
         }
      }
   }

   public int getIndex() {
      for (int i = 0; i < this.options.length; i++) {
         if (this.options[i].equals(this.value)) {
            return i;
         }
      }

      return 0;
   }

   @Override
   public void render(class_332 drawContext, int x, int y, int mouseX, int mouseY, class_327 textRenderer) {
      super.render(drawContext, x, y, mouseX, mouseY, textRenderer);
      drawContext.method_51433(textRenderer, this.name + ": " + this.value, x + 5, y + 8, -1, false);
   }

   @Override
   public void mouseClicked(double mouseX, double mouseY, int button) {
      if (this.hovered((int)mouseX, (int)mouseY)) {
         int currentIndex = this.getIndex();
         if (button == 0) {
            currentIndex = (currentIndex + 1) % this.options.length;
         } else if (button == 1) {
            currentIndex = (currentIndex - 1 + this.options.length) % this.options.length;
         }

         this.setValue(this.options[currentIndex]);
      }
   }
}
