package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.DoubleSetting;
import net.aether.aether.module.settings.StringSetting;
import net.aether.aether.util.Timer;

public class ChatSpammer extends Module {
   public StringSetting message = new StringSetting("Message", "MARLOW LOST TO Aether Team LOLOLOL");
   public DoubleSetting delay = new DoubleSetting("Delay (Seconds)", 1.0, 0.1, 10.0, 1);
   private Timer timer = new Timer();

   public ChatSpammer() {
      super("Chat Spammer", "Spams a selected message in chat.", Category.CHAT, false);
      this.settings.add(this.message);
      this.settings.add(this.delay);
   }

   @Override
   public void tick() {
      if (this.timer.hasTimeElapsed((long)this.delay.value * 1000L, true)) {
         mc.field_1724.field_3944.method_45729(this.message.value);
      }
   }
}
