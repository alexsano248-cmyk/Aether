package net.aether.aether.module.settings;

import net.minecraft.class_327;
import net.minecraft.class_332;

public class Setting {
   public String name;
   int x = 0;
   int y = 0;

   public void render(class_332 drawContext, int x, int y, int mouseX, int mouseY, class_327 textRenderer) {
      this.x = x;
      this.y = y;
      drawContext.method_25294(x, y, x + 192, y + 24, this.hovered(mouseX, mouseY) ? -12303292 : -14540254);
   }

   public void mouseClicked(double mouseX, double mouseY, int button) {
   }

   public void mouseReleased(double mouseX, double mouseY, int button) {
   }

   public void keyPressed(int keyCode, int scanCode, int modifiers) {
   }

   protected boolean hovered(int mouseX, int mouseY) {
      return mouseX >= this.x && mouseX <= this.x + 192 && mouseY >= this.y && mouseY <= this.y + 24;
   }
}
