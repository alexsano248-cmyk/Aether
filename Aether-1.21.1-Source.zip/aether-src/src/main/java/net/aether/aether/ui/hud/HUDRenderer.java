package net.aether.aether.ui.hud;

import net.aether.aether.module.ModuleManager;
import net.aether.aether.module.modules.TargetHUD;
import net.aether.aether.module.modules.Watermark;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class HUDRenderer {
   public static HUDRenderer INSTANCE = new HUDRenderer();
   private class_310 mc = class_310.method_1551();

   public void render(class_332 drawContext) {
      if (!this.mc.method_53526().method_53536()) {
         for (HUDModule h : HUDModuleManager.INSTANCE.getEnabledModules()) {
            h.render(drawContext, 0, 0, this.mc.field_1772, false, true);
         }
         try {
            net.aether.aether.module.Module wm = ModuleManager.INSTANCE.getModuleByName("Watermark");
            if (wm instanceof Watermark && wm.enabled) ((Watermark) wm).render(drawContext);
            net.aether.aether.module.Module th = ModuleManager.INSTANCE.getModuleByName("TargetHUD");
            if (th instanceof TargetHUD && th.enabled) ((TargetHUD) th).render(drawContext);
         } catch (Throwable ignored) {}
      }
   }
}
