package net.aether.aether.mixin;

import net.aether.aether.module.ModuleManager;
import net.aether.aether.module.modules.HUDEnabler;
import net.aether.aether.ui.LegacyHUD;
import net.aether.aether.ui.ModulesListOverlay;
import net.aether.aether.ui.hud.HUDRenderer;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_329.class})
public class InGameHudMixin {
   @Inject(
      at = {@At("TAIL")},
      method = {"render"}
   )
   public void onRender(class_332 drawContext, class_9779 tickCounter, CallbackInfo info) {
      HUDEnabler hudModule = (HUDEnabler)ModuleManager.INSTANCE.getModuleByName("HUD");
      if (hudModule.enabled) {
         if (hudModule.mode.index == 1) {
            LegacyHUD.INSTANCE.render(drawContext, drawContext.method_51421(), drawContext.method_51443());
         } else {
            HUDRenderer.INSTANCE.render(drawContext);
         }
      }

      if (ModuleManager.INSTANCE.getModuleByName("ModulesList").enabled) {
         ModulesListOverlay.INSTANCE.render(drawContext, drawContext.method_51421(), drawContext.method_51443());
      }
   }
}
