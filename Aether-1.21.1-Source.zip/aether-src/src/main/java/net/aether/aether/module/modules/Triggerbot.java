package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.BooleanSetting;
import net.aether.aether.util.InteractionUtil;

public class Triggerbot extends Module {
   BooleanSetting rightClick = new BooleanSetting("Require Right Click", false);

   public Triggerbot() {
      super("Triggerbot", "Automatically attacks entities in crosshair.", Category.COMBAT, true);
      this.settings.add(this.rightClick);
   }

   @Override
   public void tick() {
      assert mc.field_1724 != null;

      if (InteractionUtil.isLookingAtPlayer(9.0) && mc.field_1724.method_7261(0.5F) >= 1.0F) {
         if (this.rightClick.value) {
            if (InteractionUtil.inputActive("right")) {
               InteractionUtil.leftClick();
            }
         } else {
            InteractionUtil.leftClick();
         }
      }
   }
}
