package net.aether.aether.command.commands;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.aether.aether.command.Command;
import net.minecraft.class_1297;
import net.minecraft.class_2172;
import net.minecraft.class_746;

public class VClip extends Command {
   public VClip() {
      super("vclip", "Teleports you vertically.");
   }

   @Override
   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(argument("blocks", DoubleArgumentType.doubleArg()).executes(context -> {
         class_746 player = mc.field_1724;

         assert player != null;

         double blocks = (Double)context.getArgument("blocks", Double.class);
         if (player.method_5765()) {
            class_1297 vehicle = player.method_5854();
            vehicle.method_5814(vehicle.method_23317(), vehicle.method_23318() + blocks, vehicle.method_23321());
         }

         player.method_5814(player.method_23317(), player.method_23318() + blocks, player.method_23321());
         return this.SINGLE_SUCCESS;
      }));
   }
}
