package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.BooleanSetting;
import net.aether.aether.module.settings.DoubleSetting;
import net.aether.aether.module.settings.StringSetting;
import net.aether.aether.util.InteractionUtil;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public class AutoRekit extends Module {
   public StringSetting kit = new StringSetting("Command to type", "kit 1");
   public DoubleSetting count2 = new DoubleSetting("Amount of totems", 3.0, 0.0, 20.0, 0);
   public BooleanSetting gui = new BooleanSetting("Rekit in GUI", true);

   public AutoRekit() {
      super("Auto Rekit", "Automatically rekits when you run out of totems.", Category.COMBAT, true);
      this.settings.add(this.kit);
      this.settings.add(this.count2);
      this.settings.add(this.gui);
   }

   @Override
   public void tick() {
      int count = 0;

      for (int i = 0; i < 36; i++) {
         class_1799 stack = mc.field_1724.method_31548().method_5438(i);
         if (stack.method_7909() == class_1802.field_8288) {
            count += stack.method_7947();
         }
      }

      if ((double)count <= this.count2.value) {
         if (!this.gui.value && InteractionUtil.isPlaying()) {
            mc.field_1724.field_3944.method_45730(this.kit.value);
         } else {
            mc.field_1724.field_3944.method_45730(this.kit.value);
         }
      }
   }
}
