package net.aether.aether.ui.hud.modules;

import net.aether.aether.ui.hud.HUDModule;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class TotemCounter extends HUDModule {
   public TotemCounter(int x, int y) {
      super("Totem Counter", x, y);
      this.width = 24;
      this.height = 16;
   }

   @Override
   public void render(class_332 drawContext, int mouseX, int mouseY, class_327 textRenderer, boolean editMode, boolean enabled) {
      super.render(drawContext, mouseX, mouseY, textRenderer, editMode, enabled);
      int count = 0;

      for (int i = 0; i < 36; i++) {
         class_1799 stack = mc.field_1724.method_31548().method_5438(i);
         if (stack.method_7909() == class_1802.field_8288) {
            count += stack.method_7947();
         }
      }

      drawContext.method_51427(class_1802.field_8288.method_7854(), this.x, this.y);
      drawContext.method_25303(textRenderer, count + "", this.x + 16, this.y + 8, 16777215);
   }
}
