package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;

public class AutoRespawn extends Module {
   public AutoRespawn() {
      super("Auto Respawn", "Automatically respawns you after death.", Category.PLAYER, false);
   }

   @Override
   public void onEnable() {
      super.onEnable();
   }

   @Override
   public void tick() {
      if (mc.field_1724.method_6032() <= 0.0F) {
         mc.field_1724.method_7331();
      }
   }
}
