package net.aether.aether.module.settings;

import net.aether.aether.util.KeycodeUtils;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class StringSetting extends Setting {
   public String value;
   private boolean focused = false;

   public StringSetting(String name, String value) {
      this.name = name;
      this.value = value;
   }

   @Override
   public void render(class_332 drawContext, int x, int y, int mouseX, int mouseY, class_327 textRenderer) {
      super.render(drawContext, x, y, mouseX, mouseY, textRenderer);
      drawContext.method_27535(textRenderer, class_2561.method_43470(this.name), x + 2, y + 8, 16777215);
      int twidth = textRenderer.method_1727(this.value);
      drawContext.method_25294(x + 96, y + 5, x + 190, y + 19, -1);
      drawContext.method_25294(x + 97, y + 6, x + 189, y + 18, -14540254);
      int cursorPos = x + 98 + twidth;
      if (this.focused) {
         drawContext.method_25294(cursorPos, y + 7, cursorPos + 1, y + 17, -11141121);
      }

      drawContext.method_25303(textRenderer, this.value, x + 98, y + 8, 16777215);
   }

   @Override
   public void mouseClicked(double mouseX, double mouseY, int button) {
      if (this.focused) {
         this.focused = false;
      } else {
         if (this.hovered((int)mouseX, (int)mouseY) && button == 0) {
            this.focused = true;
         }
      }
   }

   @Override
   public void keyPressed(int keyCode, int scanCode, int modifiers) {
      if (this.focused) {
         if (keyCode == 256 || keyCode == 257) {
            this.focused = false;
            return;
         }

         if (keyCode == 259) {
            if (this.value.length() > 0) {
               this.value = this.value.substring(0, this.value.length() - 1);
            }

            return;
         }

         if (keyCode > 96) {
            return;
         }

         String append = KeycodeUtils.keyTable[keyCode];
         if (modifiers == 1) {
            append = KeycodeUtils.shiftedKeyTable[keyCode];
         }

         if (append == "Unknown") {
            return;
         }

         if (append == "Space") {
            append = " ";
         }

         this.value = this.value + append;
      }
   }
}
