package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.BooleanSetting;
import net.aether.aether.util.DelayUtil;
import net.aether.aether.util.InteractionUtil;
import net.aether.aether.util.RayTraceUtil;

public class Airplace extends Module {
   private static final String MODULE_ID = "Airplace";
   private final BooleanSetting amount = new BooleanSetting("Only 2 Anchors", true);

   public Airplace() {
      super("Airplace", "Makes airplacing easier", Category.COMBAT, true);
      this.settings.add(this.amount);
   }

   @Override
   public void onDisable() {
      super.onDisable();
   }

   @Override
   public void onEnable() {
      super.onEnable();
   }

   @Override
   public void tick() {
      String blockId = String.valueOf(RayTraceUtil.getLookedAtBlock(3.0));
      boolean lookingAtAnchor = blockId.equals("Block{minecraft:respawn_anchor}[charges=1]");
      if (this.amount.value) {
         if (lookingAtAnchor && InteractionUtil.holding("respawn_anchor") && InteractionUtil.inputActive("right") && DelayUtil.isDelayOver("Airplace")) {
            InteractionUtil.rightClick();
            DelayUtil.delay("Airplace", 1000L);
         }
      } else if (lookingAtAnchor && InteractionUtil.holding("respawn_anchor") && InteractionUtil.inputActive("right")) {
         InteractionUtil.rightClick();
      }
   }
}
