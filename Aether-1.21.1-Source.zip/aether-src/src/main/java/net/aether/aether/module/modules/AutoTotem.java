package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.BooleanSetting;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public class AutoTotem extends Module {
   public BooleanSetting overrideItems = new BooleanSetting("Override other items", true);

   public AutoTotem() {
      super("Auto Totem", "Automatically puts totems in offhand.", Category.COMBAT, true);
      this.settings.add(this.overrideItems);
   }

   @Override
   public void tick() {
      if (((class_1799)mc.field_1724.method_31548().field_7544.get(0)).method_7909() != class_1802.field_8288) {
         if (!mc.field_1724.method_31548().field_7544.isEmpty() && !this.overrideItems.value) {
            return;
         }

         for (int i = 0; i <= 35; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_7909() == class_1802.field_8288) {
               mc.field_1761.method_2906(0, i, 8, class_1713.field_7791, mc.field_1724);
               mc.field_1761.method_2906(0, 45, 8, class_1713.field_7791, mc.field_1724);
               mc.field_1761.method_2906(0, i, 8, class_1713.field_7791, mc.field_1724);
            }
         }
      }
   }
}
