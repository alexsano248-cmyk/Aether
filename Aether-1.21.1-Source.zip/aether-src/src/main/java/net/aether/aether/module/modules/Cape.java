package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;

public class Cape extends Module {
   public Cape() {
      super("Cape", "Enables the custom cape", Category.RENDER, false);
      this.showInModulesList.value = false;
   }
}
