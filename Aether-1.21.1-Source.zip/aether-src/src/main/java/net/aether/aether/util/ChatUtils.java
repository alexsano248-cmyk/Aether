package net.aether.aether.util;

import net.minecraft.class_2561;
import net.minecraft.class_310;

public class ChatUtils {
   private static class_310 mc = class_310.method_1551();

   public static void sendMsg(String message) {
      if (mc.field_1687 != null) {
         mc.field_1705.method_1743().method_1812(class_2561.method_43470(message));
      }
   }

   public static void sendMessage(String message) {
      if (mc.field_1687 != null) {
         mc.field_1705.method_1743().method_1812(class_2561.method_43470(message));
      }
   }

   public static void clearChat() {
      for (int i = 0; i < 20; i++) {
         sendMsg("");
      }
   }
}
