package net.aether.aether.command.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.aether.aether.command.Command;
import net.aether.aether.util.ChatUtils;
import net.aether.aether.util.ColorUtils;
import net.aether.aether.util.TickRateUtil;
import net.minecraft.class_2172;

public class TPS extends Command {
   public TPS() {
      super("tps", "Gets the TPS of the server.");
   }

   @Override
   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.executes(context -> {
         float tps = TickRateUtil.INSTANCE.getTickRate();
         ChatUtils.sendMsg(ColorUtils.aqua + "TPS: " + ColorUtils.white + String.format("%.1f", tps));
         return this.SINGLE_SUCCESS;
      });
   }
}
