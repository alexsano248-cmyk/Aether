package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;

public class ArrayList extends Module {
   public ArrayList() {
      super("ArrayList", "Shows enabled modules on side of screen", Category.RENDER, false);
      this.enabled = true;
      this.showInArrayList.value = false;
   }
}
