package net.aether.aether.util;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_239;
import net.minecraft.class_2885;
import net.minecraft.class_2886;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_408;
import net.minecraft.class_746;
import net.minecraft.class_239.class_240;
import net.minecraft.class_2828.class_2829;
import net.minecraft.class_3675.class_306;

public class InteractionUtil {
   private static final class_310 mc = class_310.method_1551();
   private static boolean cancelRightClickFlag = false;
   public static boolean cancelAttackFlag = false;
   private static int lastSlot = -1;

   public static void centerPlayer() {
      double x = (double)class_3532.method_15357(mc.field_1724.method_23317()) + 0.5;
      double z = (double)class_3532.method_15357(mc.field_1724.method_23321()) + 0.5;
      mc.field_1724.method_5814(x, mc.field_1724.method_23318(), z);
      mc.field_1724
         .field_3944
         .method_52787(new class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(), mc.field_1724.method_24828()));
   }

   public static float getPlayerHealth() {
      class_746 player = mc.field_1724;
      return player != null ? player.method_6032() : 0.0F;
   }

   public static boolean isPlayerMoving() {
      class_746 player = mc.field_1724;
      return player != null && (player.field_6212 != 0.0F || player.field_6250 != 0.0F);
   }

   public static void registerRightClickCancel() {
      UseBlockCallback.EVENT.register((UseBlockCallback)(player, world, hand, hitResult) -> {
         if (cancelRightClickFlag) {
            cancelRightClickFlag = false;
            return class_1269.field_5814;
         } else {
            return class_1269.field_5811;
         }
      });
   }

   public static void registerAttackCancel() {
      AttackEntityCallback.EVENT.register((AttackEntityCallback)(player, world, hand, entity, hitResult) -> {
         if (cancelAttackFlag) {
            cancelAttackFlag = false;
            return class_1269.field_5814;
         } else {
            return class_1269.field_5811;
         }
      });
   }

   public static void cancelCurrentRightClick() {
      cancelRightClickFlag = true;
   }

   public static void cancelCurrentAttack() {
      cancelAttackFlag = true;
   }

   public static void goToSlot(int slot) {
      class_746 player = mc.field_1724;
      if (player != null && slot >= 0 && slot < 9) {
         player.method_31548().field_7545 = slot;
      }
   }

   public static void leftClick() {
      class_746 player = mc.field_1724;
      if (player != null && mc.field_1761 != null) {
         mc.field_1690.field_1886.method_23481(true);
         class_239 hitResult = mc.field_1765;
         if (hitResult != null) {
            switch (hitResult.method_17783()) {
               case field_1331:
                  class_3966 entityHitResult = (class_3966)hitResult;
                  class_1297 targetEntity = entityHitResult.method_17782();
                  mc.field_1761.method_2918(player, targetEntity);
                  player.method_6104(class_1268.field_5808);
                  break;
               case field_1332:
                  class_3965 blockHitResult = (class_3965)hitResult;
                  mc.field_1761.method_2910(blockHitResult.method_17777(), player.method_5735());
                  player.method_6104(class_1268.field_5808);
                  break;
               default:
                  player.method_6104(class_1268.field_5808);
            }
         }
      }
   }

   public static void rightClickCrystal() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_746 player = mc.field_1724;
         class_3965 hitResult = RayTraceUtil.getLookedAtBlockState(5.0);
         if (hitResult != null && hitResult.method_17783() == class_240.field_1332 && holding("end_crystal")) {
            player.method_6104(class_1268.field_5808);
            mc.field_1724.field_3944.method_52787(new class_2885(class_1268.field_5808, hitResult, 0));
         }
      }
   }

   public static void rightClick() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_746 player = mc.field_1724;
         class_3965 hitResult = RayTraceUtil.getLookedAtBlockState(5.0);
         if (hitResult != null && hitResult.method_17783() == class_240.field_1332) {
            player.method_6104(class_1268.field_5808);
            mc.field_1724.field_3944.method_52787(new class_2885(class_1268.field_5808, hitResult, 0));
         }
      }
   }

   public static void rightClickItem() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         float yaw = mc.field_1724.method_5705(1.0F);
         float pitch = mc.field_1724.method_5695(1.0F);
         mc.field_1724.field_3944.method_52787(new class_2886(class_1268.field_5808, 0, yaw, pitch));
      }
   }

   public static boolean holding(String itemName) {
      if (mc.field_1724 == null) {
         return false;
      } else {
         class_1799 mainHandItem = mc.field_1724.method_6047();
         return mainHandItem.method_7909().toString().contains(itemName);
      }
   }

   public static void switchToBlock(String blockId) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         lastSlot = mc.field_1724.method_31548().field_7545;

         for (int i = 0; i < mc.field_1724.method_31548().method_5439(); i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_7909().toString().contains(blockId)) {
               mc.field_1724.method_31548().field_7545 = i;
               return;
            }
         }

         System.out.println("Block not found in inventory: " + blockId);
      }
   }

   public static void switchBack() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         if (lastSlot != -1) {
            mc.field_1724.method_31548().field_7545 = lastSlot;
            lastSlot = -1;
         } else {
            System.out.println("No previous slot to switch back to.");
         }
      }
   }

   public static boolean inputActive(String key) {
      class_304 keyBinding = getKeyBindingForKey(key);
      return keyBinding != null && keyBinding.method_1434();
   }

   private static class_304 getKeyBindingForKey(String key) {
      if (mc.field_1690 == null) {
         return null;
      } else {
         String var1 = key.toLowerCase();
         switch (var1) {
            case "left":
               return mc.field_1690.field_1886;
            case "right":
               return mc.field_1690.field_1904;
            case "jump":
               return mc.field_1690.field_1903;
            case "sneak":
               return mc.field_1690.field_1832;
            case "sprint":
               return mc.field_1690.field_1867;
            default:
               return getCustomKeyBinding(key);
         }
      }
   }

   private static class_304 getCustomKeyBinding(String key) {
      class_306 keyCode = class_3675.method_15981("key.keyboard." + key.toLowerCase());

      for (class_304 binding : mc.field_1690.field_1839) {
         if (binding.method_1429().equals(keyCode)) {
            return binding;
         }
      }

      return null;
   }

   public static boolean isLookingAtPlayer(double distance) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_1297 target = RayTraceUtil.getLookedAtEntity(distance);
         return target instanceof class_1657 && target != mc.field_1724;
      } else {
         return false;
      }
   }

   public static boolean isChatOpen() {
      return mc.field_1755 instanceof class_408;
   }

   public static boolean isPlaying() {
      return mc.field_1755 == null;
   }

   public static void breakCrystal(class_1297 entity) {
      if (mc.field_1724 != null && mc.field_1761 != null && entity != null) {
         mc.field_1761.method_2918(mc.field_1724, entity);
         mc.field_1724.method_6104(class_1268.field_5808);
      }
   }

   public static int findItemSlot(String itemName) {
      class_310 mc = class_310.method_1551();
      if (mc.field_1724 == null) {
         return -1;
      } else {
         for (int slot = 0; slot < 9; slot++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(slot);
            if (!stack.method_7960() && itemName.equalsIgnoreCase("end_crystal") && stack.method_7909() == class_1802.field_8301) {
               return slot;
            }
         }

         return -1;
      }
   }
}
