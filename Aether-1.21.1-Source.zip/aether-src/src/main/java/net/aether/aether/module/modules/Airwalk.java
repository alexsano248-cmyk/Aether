package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;

public class Airwalk extends Module {
   public Airwalk() {
      super("Airwalk", "Lets you walk in the air!", Category.MOVEMENT, true);
   }

   @Override
   public void onEnable() {
      super.onEnable();
      if (mc.field_1724 != null) {
         mc.field_1724.method_24830(true);
      }
   }

   @Override
   public void onDisable() {
      super.onDisable();
      if (mc.field_1724 != null) {
         mc.field_1724.method_24830(false);
      }
   }

   @Override
   public void tick() {
      if (mc.field_1724 != null) {
         mc.field_1724.method_24830(true);
         double velX = mc.field_1724.method_18798().field_1352;
         double velZ = mc.field_1724.method_18798().field_1350;
         mc.field_1724.method_18800(velX, 0.0, velZ);
         super.tick();
         if (mc.field_1690.field_1832.method_1434()) {
            mc.field_1724.method_18800(velX, -0.5, velZ);
         } else if (mc.field_1690.field_1903.method_1434()) {
            mc.field_1724.method_18800(velX, 0.5, velZ);
         }
      }
   }
}
