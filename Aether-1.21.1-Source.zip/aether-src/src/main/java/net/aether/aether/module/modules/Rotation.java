package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.DoubleSetting;

public class Rotation extends Module {
   DoubleSetting pitch = new DoubleSetting("Pitch", 0.0, 0.0, 360.0, 0);
   DoubleSetting yaw = new DoubleSetting("Yaw", 0.0, 0.0, 360.0, 0);

   public Rotation() {
      super("Rotation", "Locks camera to specified pitch and yaw.", Category.PLAYER, true);
      this.settings.add(this.pitch);
      this.settings.add(this.yaw);
   }

   @Override
   public void tick() {
      mc.field_1724.method_36457((float)this.pitch.value);
      mc.field_1724.method_36456((float)this.yaw.value);
   }
}
