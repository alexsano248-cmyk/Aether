package net.aether.aether.event.events;

import net.aether.aether.event.Event;

public class GameJoinedEvent extends Event {
}
