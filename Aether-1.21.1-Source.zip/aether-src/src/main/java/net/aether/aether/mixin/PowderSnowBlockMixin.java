package net.aether.aether.mixin;

import net.aether.aether.module.ModuleManager;
import net.minecraft.class_1297;
import net.minecraft.class_5635;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_5635.class})
public class PowderSnowBlockMixin {
   @Inject(
      at = {@At("HEAD")},
      method = {"canWalkOnPowderSnow"},
      cancellable = true
   )
   private static void canWalkOnPowderSnow(class_1297 entity, CallbackInfoReturnable<Boolean> cir) {
      if (ModuleManager.INSTANCE.getModuleByName("Anti Powder Snow").enabled) {
         cir.setReturnValue(true);
      }
   }
}
