package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;

public class Velocity extends Module {
   public Velocity() {
      super("Velocity", "Prevents player knockback when hit.", Category.COMBAT, true);
   }

   @Override
   public void onEnable() {
      super.onEnable();
   }

   @Override
   public void onDisable() {
      super.onDisable();
   }

   @Override
   public void tick() {
      if (mc.field_1724.field_6235 > 0) {
         mc.field_1724.method_18800(0.0, mc.field_1724.method_18798().field_1351 - 100.0, 0.0);
      }
   }
}
