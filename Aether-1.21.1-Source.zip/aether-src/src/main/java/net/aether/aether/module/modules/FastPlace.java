package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.BooleanSetting;
import net.aether.aether.util.InteractionUtil;

public class FastPlace extends Module {
   public BooleanSetting crystalonly = new BooleanSetting("Crystal Only", false);

   public FastPlace() {
      super("Fastplace", "Places blocks really fast", Category.COMBAT, true);
      this.settings.add(this.crystalonly);
   }

   @Override
   public void tick() {
      if (InteractionUtil.inputActive("right")) {
         if (this.crystalonly.value) {
            if (InteractionUtil.holding("end_crystal")) {
               InteractionUtil.rightClick();
            }
         } else {
            InteractionUtil.rightClick();
         }
      }
   }
}
