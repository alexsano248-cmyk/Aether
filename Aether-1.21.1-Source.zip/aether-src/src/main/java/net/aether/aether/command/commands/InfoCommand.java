package net.aether.aether.command.commands;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import net.aether.aether.command.Command;
import net.aether.aether.util.ChatUtils;
import net.aether.aether.util.ColorUtils;
import net.aether.aether.util.TickRateUtil;
import net.minecraft.class_1267;
import net.minecraft.class_2172;
import net.minecraft.class_310;
import net.minecraft.class_642;
import net.minecraft.class_746;

public class InfoCommand extends Command {
   private static final int ENTRIES_PER_PAGE = 5;

   public InfoCommand() {
      super("info", "Displays server information");
   }

   @Override
   public void build(LiteralArgumentBuilder<class_2172> builder) {
      ((LiteralArgumentBuilder)builder.then(RequiredArgumentBuilder.argument("page", IntegerArgumentType.integer(1)).executes(context -> {
         int page = IntegerArgumentType.getInteger(context, "page");
         this.showInfoPage(page);
         return this.SINGLE_SUCCESS;
      }))).executes(context -> {
         this.showInfoPage(1);
         return this.SINGLE_SUCCESS;
      });
   }

   private void showInfoPage(int page) {
      class_746 player = class_310.method_1551().field_1724;
      if (player != null) {
         class_642 serverData = class_310.method_1551().method_1558();
         int totalEntries = 7;
         int totalPages = (int)Math.ceil((double)totalEntries / 5.0);
         page = Math.max(1, Math.min(page, totalPages));
         ChatUtils.clearChat();
         ChatUtils.sendMsg(ColorUtils.aqua + "---- Server Info [" + page + "/" + totalPages + "] ----");
         switch (page) {
            case 1:
               String serverIP = serverData != null ? serverData.field_3761 : "Singleplayer";
               ChatUtils.sendMsg(ColorUtils.aqua + "Server IP: " + ColorUtils.white + serverIP);
               ChatUtils.sendMsg(ColorUtils.aqua + "Version: " + ColorUtils.white + class_310.method_1551().method_1515());
               if (serverData != null) {
                  ChatUtils.sendMsg(
                     ColorUtils.aqua + "Players: " + ColorUtils.white + serverData.field_41861.comp_1280() + " / " + serverData.field_41861.comp_1279()
                  );
                  ChatUtils.sendMsg(ColorUtils.aqua + "Ping: " + ColorUtils.white + serverData.field_3758 + "ms");
               }
               break;
            case 2:
               if (player.field_17892 != null) {
                  class_1267 difficulty = player.field_17892.method_8407();
                  ChatUtils.sendMsg(ColorUtils.aqua + "Difficulty: " + ColorUtils.white + difficulty.method_5460());
               }

               float tps = TickRateUtil.INSTANCE.getTickRate();
               ChatUtils.sendMsg(ColorUtils.aqua + "TPS: " + ColorUtils.white + String.format("%.1f", tps));
         }

         ChatUtils.sendMsg(ColorUtils.green + "Use .info <page> to navigate");
      }
   }
}
