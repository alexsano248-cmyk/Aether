package net.aether.aether.mixin;

import net.aether.aether.module.Module;
import net.aether.aether.module.ModuleManager;
import net.minecraft.class_1313;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_746.class})
public class ClientPlayerEntityMixin {
   @Inject(
      method = {"move"},
      at = {@At("TAIL")},
      cancellable = true
   )
   public void onMove(class_1313 type, class_243 movement, CallbackInfo ci) {
      for (Module m : ModuleManager.INSTANCE.getEnabledModules()) {
         m.onMotion(type, movement);
      }
   }

   @Inject(
      method = {"tick"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void onTick(CallbackInfo ci) {
      for (Module m : ModuleManager.INSTANCE.getEnabledModules()) {
         if (class_310.method_1551().field_1724 != null) {
            m.tick();
         }
      }
   }

   @Inject(
      method = {"init"},
      at = {@At("TAIL")},
      cancellable = true
   )
   public void onInit(CallbackInfo ci) {
      for (Module m : ModuleManager.INSTANCE.getEnabledModules()) {
         m.onEnable();
      }
   }
}
