package net.aether.aether.command.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.aether.aether.command.Command;
import net.aether.aether.util.ChatUtils;
import net.minecraft.class_2172;

public class ClearChat extends Command {
   public ClearChat() {
      super("clearchat", "Clears the chat.");
   }

   @Override
   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.executes(context -> {
         ChatUtils.clearChat();
         return this.SINGLE_SUCCESS;
      });
   }
}
