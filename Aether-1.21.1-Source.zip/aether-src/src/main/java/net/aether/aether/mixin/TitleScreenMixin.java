package net.aether.aether.mixin;

import net.aether.aether.Aether;
import net.aether.aether.module.ModuleManager;
import net.aether.aether.module.modules.HUDEnabler;
import net.minecraft.class_156;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_442.class})
public abstract class TitleScreenMixin extends class_437 {
   @Shadow
   @Final
   private boolean field_18222;
   @Shadow
   @Final
   private long field_17772;

   public TitleScreenMixin() {
      super(null);
   }

   @Inject(
      at = {@At("TAIL")},
      method = {"render"}
   )
   private void clientTag(class_332 drawContext, int mouseX, int mouseY, float delta, CallbackInfo info) {
      float f = this.field_18222 ? (float)(class_156.method_658() - this.field_17772) / 1000.0F : 1.0F;
      float g = this.field_18222 ? class_3532.method_15363(f - 1.0F, 0.0F, 1.0F) : 1.0F;
      int l = class_3532.method_15386(g * 255.0F) << 24;
      HUDEnabler hud = (HUDEnabler)ModuleManager.INSTANCE.getModuleByName("HUD");
      if (hud.enabled && hud.mainmenuhud.value) {
         drawContext.method_25303(this.field_22793, Aether.clientTag + " " + Aether.versionTag, 2, 2, 16777215 | l);
      }
   }
}
