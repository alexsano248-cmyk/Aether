package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.BooleanSetting;
import net.aether.aether.module.settings.DropdownSetting;
import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2596;
import net.minecraft.class_3965;
import net.minecraft.class_243;

public class Scaffold extends Module {
   public final DropdownSetting rotation = new DropdownSetting("Rotation", "Normal", new String[]{"None", "Normal", "OmniPred"});
   public final BooleanSetting sprint = new BooleanSetting("Keep Sprint", true);
   public final BooleanSetting swing = new BooleanSetting("Swing", true);

   public Scaffold() {
      super("Scaffold", "Automatically places blocks beneath you.", Category.WORLD, false);
      this.settings.add(this.rotation);
      this.settings.add(this.sprint);
      this.settings.add(this.swing);
   }

   private int findBlockSlot() {
      for (int i = 0; i < 9; i++) {
         class_1799 s = mc.field_1724.method_31548().method_5438(i);
         if (!s.method_7960() && s.method_7909() instanceof class_1747) return i;
      }
      return -1;
   }

   @Override
   public void tick() {
      if (mc.field_1724 == null || mc.field_1687 == null) return;
      int slot = findBlockSlot();
      if (slot < 0) return;
      int oldSel = mc.field_1724.method_31548().field_7545;
      mc.field_1724.method_31548().field_7545 = slot;

      class_2338 below = mc.field_1724.method_24515().method_10074();
      if (!mc.field_1687.method_8320(below).method_26215()) {
         mc.field_1724.method_31548().field_7545 = oldSel;
         return;
      }
      // Find supporting neighbor
      for (class_2350 dir : class_2350.values()) {
         class_2338 neighbor = below.method_10093(dir);
         if (!mc.field_1687.method_8320(neighbor).method_26215()) {
            class_243 hit = class_243.method_24953(below).method_1019(class_243.method_24954(dir.method_10153().method_10163()).method_1021(0.5));
            class_3965 res = new class_3965(hit, dir.method_10153(), neighbor, false);
            mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, res);
            if (this.swing.value) mc.field_1724.method_6104(class_1268.field_5808);
            break;
         }
      }
      mc.field_1724.method_31548().field_7545 = oldSel;
   }
}
