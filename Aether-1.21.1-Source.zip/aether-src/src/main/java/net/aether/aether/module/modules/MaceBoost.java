package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.DoubleSetting;
import net.aether.aether.util.InteractionUtil;
import net.minecraft.class_3966;
import net.minecraft.class_2828.class_2829;

public class MaceBoost extends Module {
   private boolean shouldBoost = false;
   DoubleSetting height = new DoubleSetting("Height", 30.0, 10.0, 50.0, 0);

   public MaceBoost() {
      super("MaceBoost", "Instantly kills people with a mace", Category.COMBAT, true);
      InteractionUtil.registerAttackCancel();
      this.settings.add(this.height);
   }

   @Override
   public void tick() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         if (mc.field_1690.field_1886.method_1434()
            && mc.field_1724.method_7261(0.1F) <= 1.0F
            && InteractionUtil.holding("mace")
            && mc.field_1765 instanceof class_3966) {
            InteractionUtil.cancelCurrentAttack();
            this.shouldBoost = true;
         }

         if (this.shouldBoost) {
            double x = mc.field_1724.method_23317();
            double y = mc.field_1724.method_23318();
            double z = mc.field_1724.method_23321();
            if (mc.field_1765 instanceof class_3966 entityHit) {
               InteractionUtil.cancelAttackFlag = false;
               mc.field_1724.field_3944.method_52787(new class_2829(x, y, z, false));
               mc.field_1724.field_3944.method_52787(new class_2829(x, y + this.height.value, z, false));
               mc.field_1724.field_3944.method_52787(new class_2829(x, y, z, false));
               mc.field_1761.method_2918(mc.field_1724, entityHit.method_17782());
               this.shouldBoost = false;
            }
         }
      }
   }

   @Override
   public void onDisable() {
      super.onDisable();
      this.shouldBoost = false;
   }
}
