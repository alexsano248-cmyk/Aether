package net.aether.aether.ui.hud.modules;

import net.aether.aether.ui.hud.HUDModule;
import net.aether.aether.util.ColorUtils;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class FPS extends HUDModule {
   public FPS(int x, int y) {
      super("FPS", x, y);
      this.width = 48;
      this.height = 8;
      this.enabled = true;
   }

   @Override
   public void render(class_332 drawContext, int mouseX, int mouseY, class_327 textRenderer, boolean editMode, boolean enabled) {
      super.render(drawContext, mouseX, mouseY, textRenderer, editMode, enabled);
      drawContext.method_25303(mc.field_1772, ColorUtils.aqua + "FPS: " + ColorUtils.white + mc.field_1770.split(" ")[0], this.x, this.y, -11141121);
   }
}
