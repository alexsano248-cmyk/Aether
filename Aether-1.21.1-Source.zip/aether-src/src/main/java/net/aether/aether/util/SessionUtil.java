package net.aether.aether.util;

import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_310;
import net.minecraft.class_320;
import net.minecraft.class_320.class_321;

public class SessionUtil {
   private static final class_310 mc = class_310.method_1551();

   public static void setOfflineUsername(String username) {
      if (username != null && !username.isEmpty()) {
         try {
            UUID uuid = UUID.randomUUID();
            class_320 newSession = new class_320(username, uuid, "", Optional.empty(), Optional.empty(), class_321.field_1988);
            ReflectionUtils.setPrivateField(class_310.class, mc, "session", newSession);
         } catch (Exception var3) {
            var3.printStackTrace();
         }
      }
   }

   public static String getCurrentUsername() {
      try {
         class_320 session = (class_320)ReflectionUtils.getPrivateField(class_310.class, mc, "session");
         return session.method_1676();
      } catch (Exception var1) {
         var1.printStackTrace();
         return "";
      }
   }

   public static boolean isOffline() {
      try {
         class_320 session = (class_320)ReflectionUtils.getPrivateField(class_310.class, mc, "session");
         return session.method_44717() == null;
      } catch (Exception var1) {
         var1.printStackTrace();
         return true;
      }
   }
}
