package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.DoubleSetting;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_243;

public class BowAimbot extends Module {
   public final DoubleSetting range = new DoubleSetting("Range", 60.0, 5.0, 120.0, 0);

   public BowAimbot() {
      super("BowAimbot", "Aims your bow at the closest player while drawing.", Category.COMBAT, true);
      this.settings.add(this.range);
   }

   @Override
   public void tick() {
      if (mc.field_1724 == null || mc.field_1687 == null) return;
      if (!mc.field_1724.method_6115()) return;
      if (mc.field_1724.method_6030().method_7909() != class_1802.field_8102) return;

      class_1309 best = null; double bestDist = this.range.value;
      for (class_1297 e : mc.field_1687.method_18112()) {
         if (!(e instanceof class_1657)) continue;
         if (e == mc.field_1724) continue;
         double d = mc.field_1724.method_5739(e);
         if (d <= bestDist) { bestDist = d; best = (class_1309) e; }
      }
      if (best == null) return;
      class_243 eye = mc.field_1724.method_33571();
      class_243 tgt = best.method_33571();
      double dx = tgt.field_1352 - eye.field_1352;
      double dy = tgt.field_1351 - eye.field_1351;
      double dz = tgt.field_1350 - eye.field_1350;
      double horiz = Math.sqrt(dx*dx + dz*dz);
      // Simple ballistic compensation
      float yaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
      float pitch = (float)(-Math.toDegrees(Math.atan2(dy + horiz * 0.06, horiz)));
      mc.field_1724.method_36456(yaw);
      mc.field_1724.method_36457(pitch);
   }
}
