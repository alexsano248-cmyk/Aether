package net.aether.aether.event;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public class Event {
   @Retention(RetentionPolicy.RUNTIME)
   public @interface EventHandler {
   }

   public interface Listener {
      void invoke(Event var1);
   }
}
