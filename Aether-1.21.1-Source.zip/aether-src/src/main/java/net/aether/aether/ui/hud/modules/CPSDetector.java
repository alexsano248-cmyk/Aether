package net.aether.aether.ui.hud.modules;

import net.aether.aether.ui.hud.HUDModule;
import net.aether.aether.util.ClickCounter;
import net.aether.aether.util.ColorUtils;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class CPSDetector extends HUDModule {
   public CPSDetector(int x, int y) {
      super("CPS", x, y);
      this.width = 48;
      this.height = 8;
      this.enabled = true;
   }

   @Override
   public void render(class_332 drawContext, int mouseX, int mouseY, class_327 textRenderer, boolean editMode, boolean enabled) {
      super.render(drawContext, mouseX, mouseY, textRenderer, editMode, enabled);
      int leftCps = ClickCounter.INSTANCE.getLeftCPS();
      int rightCps = ClickCounter.INSTANCE.getRightCPS();
      String cpsText = ColorUtils.aqua + leftCps + ColorUtils.white + " / " + ColorUtils.aqua + rightCps;
      this.width = textRenderer.method_1727(cpsText);
      drawContext.method_25303(textRenderer, cpsText, this.x, this.y, 16777215);
   }
}
