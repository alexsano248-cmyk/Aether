package net.aether.aether.ui;

import net.aether.aether.util.SessionUtil;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class SessionManagerScreen extends class_437 {
   private class_342 usernameField;
   private String status = "";

   public SessionManagerScreen() {
      super(class_2561.method_43470("Session Manager"));
   }

   protected void method_25426() {
      super.method_25426();
      int centerX = this.field_22789 / 2;
      int centerY = this.field_22790 / 2;
      this.usernameField = new class_342(this.field_22793, centerX - 100, centerY - 20, 200, 20, class_2561.method_43470("Username"));
      this.usernameField.method_1880(16);
      this.usernameField.method_1852(SessionUtil.getCurrentUsername());
      this.method_37063(this.usernameField);
      class_4185 setButton = class_4185.method_46430(class_2561.method_43470("Set Username"), button -> {
         String username = this.usernameField.method_1882();
         if (!username.isEmpty()) {
            SessionUtil.setOfflineUsername(username);
            this.status = "Username set to: " + username;
            this.method_25419();
         } else {
            this.status = "Please enter a username!";
         }
      }).method_46434(centerX - 50, centerY + 20, 100, 20).method_46431();
      this.method_37063(setButton);
      class_4185 backButton = class_4185.method_46430(class_2561.method_43470("Back"), button -> this.method_25419())
         .method_46434(centerX - 50, centerY + 50, 100, 20)
         .method_46431();
      this.method_37063(backButton);
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
      this.method_25420(context, mouseX, mouseY, delta);
      super.method_25394(context, mouseX, mouseY, delta);
      int centerX = this.field_22789 / 2;
      int centerY = this.field_22790 / 2;
      context.method_27534(this.field_22793, this.field_22785, centerX, centerY - 60, 16777215);
      context.method_25303(this.field_22793, "Username:", centerX - 100, centerY - 35, 16777215);
      if (!this.status.isEmpty()) {
         context.method_25300(this.field_22793, this.status, centerX, centerY + 80, 16777215);
      }
   }

   public boolean method_25421() {
      return false;
   }
}
