package net.aether.aether.ui.hud.modules;

import net.aether.aether.ui.hud.HUDModule;
import net.aether.aether.util.ColorUtils;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class Coordinates extends HUDModule {
   public Coordinates(int x, int y) {
      super("Coordinates", x, y);
      this.width = 128;
      this.height = 8;
      this.enabled = true;
   }

   @Override
   public void render(class_332 drawContext, int mouseX, int mouseY, class_327 textRenderer, boolean editMode, boolean enabled) {
      super.render(drawContext, mouseX, mouseY, textRenderer, editMode, enabled);
      drawContext.method_25303(
         mc.field_1772,
         "X: "
            + ColorUtils.white
            + String.format("%.1f", mc.field_1724.method_23317())
            + ColorUtils.reset
            + " Y: "
            + ColorUtils.white
            + String.format("%.1f", mc.field_1724.method_23318())
            + ColorUtils.reset
            + " Z: "
            + ColorUtils.white
            + String.format("%.1f", mc.field_1724.method_23321()),
         this.x,
         this.y,
         -11141121
      );
   }
}
