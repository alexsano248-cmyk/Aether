package net.aether.aether.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.ParseResults;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.aether.aether.Aether;
import net.aether.aether.command.commands.Bind;
import net.aether.aether.command.commands.CPS;
import net.aether.aether.command.commands.CenterPos;
import net.aether.aether.command.commands.ClearChat;
import net.aether.aether.command.commands.DeathPos;
import net.aether.aether.command.commands.Help;
import net.aether.aether.command.commands.InfoCommand;
import net.aether.aether.command.commands.Mode;
import net.aether.aether.command.commands.Ping;
import net.aether.aether.command.commands.Prefix;
import net.aether.aether.command.commands.Reset;
import net.aether.aether.command.commands.SettingCommand;
import net.aether.aether.command.commands.TPS;
import net.aether.aether.command.commands.Teleport;
import net.aether.aether.command.commands.Toggle;
import net.aether.aether.command.commands.VClip;
import net.minecraft.class_2172;
import net.minecraft.class_310;
import net.minecraft.class_637;

public class CommandManager {
   private static class_310 mc = class_310.method_1551();
   private final CommandDispatcher<class_2172> DISPATCHER = new CommandDispatcher();
   private final class_2172 COMMAND_SOURCE = new CommandManager.ChatCommandSource(mc);
   private final List<Command> commands = new ArrayList<>();
   private final Map<Class<? extends Command>, Command> commandInstances = new HashMap<>();
   public static String prefix = ".";

   public CommandManager() {
      this.add(new VClip());
      this.add(new Help());
      this.add(new Toggle());
      this.add(new Teleport());
      this.add(new SettingCommand());
      this.add(new Reset());
      this.add(new DeathPos());
      this.add(new InfoCommand());
      this.add(new CenterPos());
      this.add(new Ping());
      this.add(new TPS());
      this.add(new CPS());
      this.add(new Prefix());
      this.add(new ClearChat());
      this.add(new Mode());
      this.add(new Bind());
      this.commands.sort(Comparator.comparing(Command::getName));
   }

   public static CommandManager get() {
      return new CommandManager();
   }

   public void dispatch(String message) throws CommandSyntaxException {
      this.dispatch(message, new CommandManager.ChatCommandSource(mc));
   }

   public void dispatch(String message, class_2172 source) throws CommandSyntaxException {
      ParseResults<class_2172> results = this.DISPATCHER.parse(message, source);
      this.DISPATCHER.execute(results);
   }

   public CommandDispatcher<class_2172> getDispatcher() {
      return this.DISPATCHER;
   }

   public class_2172 getCommandSource() {
      return this.COMMAND_SOURCE;
   }

   public void add(Command command) {
      this.commands.removeIf(command1 -> command1.getName().equals(command.getName()));
      this.commandInstances.values().removeIf(command1 -> command1.getName().equals(command.getName()));
      command.registerTo(this.DISPATCHER);
      this.commands.add(command);
      this.commandInstances.put((Class<? extends Command>)command.getClass(), command);
   }

   public int getCount() {
      return this.commands.size();
   }

   public List<Command> getAll() {
      return this.commands;
   }

   public <T extends Command> T get(Class<T> klass) {
      return (T)this.commandInstances.get(klass);
   }

   public void setPrefix(String selectedPrefix) {
      prefix = selectedPrefix;
      Aether.INSTANCE.saveConfig();
   }

   public String getPrefix() {
      return prefix;
   }

   private static final class ChatCommandSource extends class_637 {
      public ChatCommandSource(class_310 client) {
         super(null, client);
      }
   }
}
