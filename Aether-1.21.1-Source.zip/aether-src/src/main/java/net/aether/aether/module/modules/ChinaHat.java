package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.DoubleSetting;

public class ChinaHat extends Module {
   public final DoubleSetting size = new DoubleSetting("Size", 1.0, 0.2, 4.0, 1);
   public final DoubleSetting height = new DoubleSetting("Height", 0.5, 0.0, 3.0, 1);

   public ChinaHat() {
      super("ChinaHat", "Renders a cone above your head.", Category.RENDER, false);
      this.settings.add(this.size);
      this.settings.add(this.height);
   }
   // Rendering hook is performed by a WorldRenderEvent listener (see render package mixins).
}
