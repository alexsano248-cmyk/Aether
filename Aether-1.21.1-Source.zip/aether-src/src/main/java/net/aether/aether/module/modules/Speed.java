package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.BooleanSetting;
import net.aether.aether.module.settings.DoubleSetting;
import net.minecraft.class_5134;

public class Speed extends Module {
   double old = 0.1;
   BooleanSetting strafe = new BooleanSetting("Strafe", true);
   BooleanSetting jump = new BooleanSetting("Jump", true);
   DoubleSetting speed = new DoubleSetting("Speed", 1.4, 0.1, 10.0, 1);

   public Speed() {
      super("Speed", "Allows you to move faster.", Category.MOVEMENT, true);
      this.settings.add(this.speed);
      this.settings.add(this.strafe);
      this.settings.add(this.jump);
   }

   @Override
   public void onEnable() {
      super.onEnable();
      this.old = mc.field_1724.method_5996(class_5134.field_23719).method_6201();
   }

   @Override
   public void tick() {
      mc.field_1724.method_5996(class_5134.field_23719).method_6192(this.speed.value / 10.0);
      if (mc.field_1724 != null
         && mc.field_1724.method_24828()
         && this.jump.value
         && (mc.field_1724.field_3913.field_3905 != 0.0F || mc.field_1724.field_3913.field_3907 != 0.0F)) {
         mc.field_1724.method_6043();
      }

      if (this.strafe.value) {
         mc.field_1724.method_24830(true);
         mc.field_1690.field_1903.method_23481(false);
      }
   }

   @Override
   public void onDisable() {
      super.onDisable();
      mc.field_1724.method_5996(class_5134.field_23719).method_6192(this.old);
   }
}
