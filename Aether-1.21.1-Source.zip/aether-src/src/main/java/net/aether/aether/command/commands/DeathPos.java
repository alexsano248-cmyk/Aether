package net.aether.aether.command.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.aether.aether.command.Command;
import net.aether.aether.util.ChatUtils;
import net.aether.aether.util.ColorUtils;
import net.minecraft.class_2172;
import net.minecraft.class_4208;

public class DeathPos extends Command {
   public DeathPos() {
      super("deathpos", "Shows your last death position.");
   }

   @Override
   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.executes(
         context -> {
            class_4208 pos = null;

            try {
               pos = (class_4208)mc.field_1724.method_43122().get();
               if (pos == null) {
                  throw new Exception();
               }
            } catch (Exception var4) {
               ChatUtils.sendMsg(ColorUtils.reset + "You have not died in this world.");
               return this.SINGLE_SUCCESS;
            }

            ChatUtils.sendMsg(
               ColorUtils.reset
                  + "You last died at: "
                  + ColorUtils.aqua
                  + " X: "
                  + ColorUtils.gray
                  + pos.comp_2208().method_10263()
                  + ColorUtils.aqua
                  + " Y: "
                  + ColorUtils.gray
                  + pos.comp_2208().method_10264()
                  + ColorUtils.aqua
                  + " Z: "
                  + ColorUtils.gray
                  + pos.comp_2208().method_10260()
            );
            return this.SINGLE_SUCCESS;
         }
      );
   }
}
