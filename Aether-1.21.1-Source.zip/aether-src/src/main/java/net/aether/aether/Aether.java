package net.aether.aether;

import java.util.HashMap;
import java.util.Map;
import net.aether.aether.command.CommandManager;
import net.aether.aether.module.Module;
import net.aether.aether.module.ModuleManager;
import net.aether.aether.module.settings.BooleanSetting;
import net.aether.aether.module.settings.DoubleSetting;
import net.aether.aether.module.settings.IndexSetting;
import net.aether.aether.module.settings.KeycodeSetting;
import net.aether.aether.module.settings.Setting;
import net.aether.aether.module.settings.StringSetting;
import net.aether.aether.ui.clickgui.CategoryPane;
import net.aether.aether.ui.clickgui.ClickGUIScreen;
import net.aether.aether.ui.hud.HUDModule;
import net.aether.aether.ui.hud.HUDModuleManager;
import net.aether.aether.util.AuthUtil;
import net.aether.aether.util.ColorUtils;
import net.aether.aether.util.InteractionUtil;
import net.aether.aether.util.KeycodeUtils;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.EndTick;
import net.minecraft.class_408;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Aether implements ModInitializer {
   public static final Aether INSTANCE = new Aether();
   public static final Logger LOGGER = LoggerFactory.getLogger("Aether");
   public static final String clientTag = ColorUtils.aqua + "Aether";
   public static final String versionTag = ColorUtils.magenta + "v1.0";
   public static final String VERSION = "1.0";
   public static Config CONFIG = new Config();
   public static boolean loaded = false;
   private String prefix = new CommandManager().getPrefix();

   public void onInitialize() {
      this.loadConfig();
      ClientTickEvents.END_CLIENT_TICK.register((EndTick)client -> {
         if (client.field_1724 != null) {
            if (AuthUtil.isAuthorized()) {
               if (!InteractionUtil.isChatOpen()) {
                  this.prefix = new CommandManager().getPrefix();
                  if (KeycodeUtils.isKeyPressed(this.prefix)) {
                     client.method_1507(new class_408(this.prefix));
                  }
               }
            }
         }
      });
   }

   public void loadConfig() {
      try {
         CONFIG.load();

         for (Module m : ModuleManager.INSTANCE.modules) {
            m.enabled = (Boolean)((Map)((Map)CONFIG.config.get("modules")).get(m.name)).get("enabled");

            for (Setting s : m.settings) {
               if (s instanceof BooleanSetting) {
                  ((BooleanSetting)s).value = (Boolean)((Map)((Map)((Map)CONFIG.config.get("modules")).get(m.name)).get("settings")).get(s.name);
               } else if (s instanceof DoubleSetting) {
                  ((DoubleSetting)s).value = (Double)((Map)((Map)((Map)CONFIG.config.get("modules")).get(m.name)).get("settings")).get(s.name);
               } else if (s instanceof StringSetting) {
                  ((StringSetting)s).value = (String)((Map)((Map)((Map)CONFIG.config.get("modules")).get(m.name)).get("settings")).get(s.name);
               } else if (s instanceof KeycodeSetting) {
                  ((KeycodeSetting)s).value = ((Double)((Map)((Map)((Map)CONFIG.config.get("modules")).get(m.name)).get("settings")).get(s.name)).intValue();
               } else if (s instanceof IndexSetting) {
                  ((IndexSetting)s).index = ((Double)((Map)((Map)((Map)CONFIG.config.get("modules")).get(m.name)).get("settings")).get(s.name)).intValue();
               }
            }
         }

         for (HUDModule m : HUDModuleManager.INSTANCE.modules) {
            m.enabled = (Boolean)((Map)((Map)CONFIG.config.get("hud")).get(m.name)).get("enabled");
            m.x = ((Double)((Map)((Map)CONFIG.config.get("hud")).get(m.name)).get("x")).intValue();
            m.y = ((Double)((Map)((Map)CONFIG.config.get("hud")).get(m.name)).get("y")).intValue();

            for (Setting sx : m.settings) {
               if (sx instanceof BooleanSetting) {
                  ((BooleanSetting)sx).value = (Boolean)((Map)((Map)((Map)CONFIG.config.get("hud")).get(m.name)).get("settings")).get(sx.name);
               } else if (sx instanceof DoubleSetting) {
                  ((DoubleSetting)sx).value = (Double)((Map)((Map)((Map)CONFIG.config.get("hud")).get(m.name)).get("settings")).get(sx.name);
               } else if (sx instanceof StringSetting) {
                  ((StringSetting)sx).value = (String)((Map)((Map)((Map)CONFIG.config.get("hud")).get(m.name)).get("settings")).get(sx.name);
               } else if (sx instanceof KeycodeSetting) {
                  ((KeycodeSetting)sx).value = ((Double)((Map)((Map)((Map)CONFIG.config.get("hud")).get(m.name)).get("settings")).get(sx.name)).intValue();
               } else if (sx instanceof IndexSetting) {
                  ((IndexSetting)sx).index = ((Double)((Map)((Map)((Map)CONFIG.config.get("hud")).get(m.name)).get("settings")).get(sx.name)).intValue();
               }
            }
         }

         Map<String, Object> general = (Map<String, Object>)CONFIG.config.get("general");
         if (general != null) {
            String savedPrefix = (String)general.get("prefix");
            if (savedPrefix != null) {
               new CommandManager().setPrefix(savedPrefix);
            }
         }
      } catch (Exception var5) {
         CONFIG.loadDefaultConfig();
         CONFIG.save();
      }
   }

   public void saveConfig() {
      Map<String, Object> mi = new HashMap<>();

      for (Module m : ModuleManager.INSTANCE.modules) {
         Map<String, Object> mo = new HashMap<>();
         mo.put("enabled", m.enabled);
         Map<String, Object> ms = new HashMap<>();

         for (Setting s : m.settings) {
            if (s instanceof BooleanSetting) {
               ms.put(s.name, ((BooleanSetting)s).value);
            } else if (s instanceof DoubleSetting) {
               ms.put(s.name, ((DoubleSetting)s).value);
            } else if (s instanceof StringSetting) {
               ms.put(s.name, ((StringSetting)s).value);
            } else if (s instanceof KeycodeSetting) {
               ms.put(s.name, ((KeycodeSetting)s).value);
            } else if (s instanceof IndexSetting) {
               ms.put(s.name, ((IndexSetting)s).index);
            }
         }

         mo.put("settings", ms);
         mi.put(m.name, mo);
      }

      CONFIG.config.put("modules", mi);
      Map<String, Object> hi = new HashMap<>();

      for (HUDModule h : HUDModuleManager.INSTANCE.modules) {
         Map<String, Object> ho = new HashMap<>();
         ho.put("enabled", h.enabled);
         Map<String, Object> hs = new HashMap<>();

         for (Setting sx : h.settings) {
            if (sx instanceof BooleanSetting) {
               hs.put(sx.name, ((BooleanSetting)sx).value);
            } else if (sx instanceof DoubleSetting) {
               hs.put(sx.name, ((DoubleSetting)sx).value);
            } else if (sx instanceof StringSetting) {
               hs.put(sx.name, ((StringSetting)sx).value);
            } else if (sx instanceof KeycodeSetting) {
               hs.put(sx.name, ((KeycodeSetting)sx).value);
            } else if (sx instanceof IndexSetting) {
               hs.put(sx.name, ((IndexSetting)sx).index);
            }
         }

         ho.put("settings", hs);
         ho.put("x", h.x);
         ho.put("y", h.y);
         hi.put(h.name, ho);
      }

      CONFIG.config.put("hud", hi);
      Map<String, Object> pi = new HashMap<>();

      for (CategoryPane c : ClickGUIScreen.INSTANCE.categoryPanes) {
         Map<String, Object> po = new HashMap<>();
         po.put("x", c.x);
         po.put("y", c.y);
         po.put("collapsed", c.collapsed);
         pi.put(c.category.name, po);
      }

      CONFIG.config.put("panes", pi);
      Map<String, Object> general = new HashMap<>();
      general.put("prefix", new CommandManager().getPrefix());
      CONFIG.config.put("general", general);
      CONFIG.save();
   }
}
