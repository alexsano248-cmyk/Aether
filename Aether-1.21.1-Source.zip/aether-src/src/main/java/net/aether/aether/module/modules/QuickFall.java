package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.BooleanSetting;
import net.minecraft.class_243;

public class QuickFall extends Module {
   BooleanSetting instantFall = new BooleanSetting("Stick to ground", false);

   public QuickFall() {
      super("QuickFall", "Makes you fall really quickly", Category.MOVEMENT, true);
      this.settings.add(this.instantFall);
   }

   @Override
   public void onDisable() {
      super.onDisable();
      if (mc.field_1724 != null) {
         class_243 currentVelocity = mc.field_1724.method_18798();
         mc.field_1724.method_18799(new class_243(currentVelocity.field_1352, 0.0, currentVelocity.field_1350));
      }
   }

   @Override
   public void tick() {
      if (mc.field_1724 != null) {
         if (!mc.field_1724.method_24828() && mc.field_1724 != null) {
            if (!this.instantFall.value) {
               if (mc.field_1724.field_6017 > 0.1F) {
                  class_243 currentVelocity = mc.field_1724.method_18798();
                  mc.field_1724.method_18799(new class_243(currentVelocity.field_1352, -10.0, currentVelocity.field_1350));
               }
            } else {
               class_243 currentVelocity = mc.field_1724.method_18798();
               mc.field_1724.method_18799(new class_243(currentVelocity.field_1352, -50.0, currentVelocity.field_1350));
            }
         }
      }
   }
}
