package net.aether.aether.ui.clickgui;

import java.util.ArrayList;
import java.util.Map;
import net.aether.aether.Aether;
import net.aether.aether.module.Category;
import net.aether.aether.util.MathUtils;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class ClickGUIScreen extends class_437 {
   public static String keybind = "right alt";
   public static ClickGUIScreen INSTANCE = new ClickGUIScreen();
   public ArrayList<CategoryPane> categoryPanes = new ArrayList<>();

   public ClickGUIScreen() {
      super(class_2561.method_43470("ClickGUI"));
      Map<String, Object> panePos = (Map<String, Object>)Aether.CONFIG.config.get("panes");

      for (Category category : Category.values()) {
         if (!category.name.equals("Special")) {
            int xOffset = MathUtils.d2iSafe(((Map)panePos.get(category.name)).get("x"));
            int yOffset = MathUtils.d2iSafe(((Map)panePos.get(category.name)).get("y"));
            boolean collapsed = (Boolean)((Map)panePos.get(category.name)).get("collapsed");
            this.categoryPanes.add(new CategoryPane(category, xOffset, yOffset, collapsed));
         }
      }
   }

   public void method_25394(class_332 drawContext, int mouseX, int mouseY, float delta) {
      this.method_25420(drawContext, mouseX, mouseY, delta);

      for (CategoryPane category : this.categoryPanes) {
         category.render(drawContext, mouseX, mouseY, delta, this.field_22793);
      }

      for (CategoryPane category : this.categoryPanes) {
         category.renderTooltips(drawContext, mouseX, mouseY, this.field_22793);
      }
   }

   public boolean method_25402(double mouseX, double mouseY, int button) {
      for (CategoryPane category : this.categoryPanes) {
         category.mouseClicked((int)mouseX, (int)mouseY, button);
      }

      return super.method_25402(mouseX, mouseY, button);
   }

   public boolean method_25406(double mouseX, double mouseY, int button) {
      for (CategoryPane category : this.categoryPanes) {
         category.mouseReleased((int)mouseX, (int)mouseY, button);
      }

      return super.method_25406(mouseX, mouseY, button);
   }

   public boolean method_25421() {
      return false;
   }
}
