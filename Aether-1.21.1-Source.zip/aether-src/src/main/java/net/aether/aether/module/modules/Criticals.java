package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;

public class Criticals extends Module {
   private boolean shouldCrit = false;

   public Criticals() {
      super("Criticals", "Critical smacks.", Category.COMBAT, true);
   }
}
