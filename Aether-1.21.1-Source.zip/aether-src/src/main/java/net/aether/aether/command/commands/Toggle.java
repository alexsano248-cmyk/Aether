package net.aether.aether.command.commands;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.aether.aether.command.Command;
import net.aether.aether.module.Module;
import net.aether.aether.module.ModuleManager;
import net.minecraft.class_2172;
import net.minecraft.class_310;

public class Toggle extends Command {
   public Toggle() {
      super("toggle", "Toggle a module on or off.");
   }

   @Override
   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(argument("module", StringArgumentType.string()).executes(context -> {
         String m = (String)context.getArgument("module", String.class);
         Module module = ModuleManager.INSTANCE.getModuleByName(m);
         class_310.method_1551().method_18858(() -> module.toggle());
         return this.SINGLE_SUCCESS;
      }));
   }
}
