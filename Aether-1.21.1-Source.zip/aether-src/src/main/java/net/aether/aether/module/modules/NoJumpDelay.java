package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.util.InteractionUtil;
import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;

public class NoJumpDelay extends Module {
   private final class_310 mc = class_310.method_1551();

   public NoJumpDelay() {
      super("NoJumpDelay", "Eliminates jump delay.", Category.MOVEMENT, true);
   }

   @Override
   public void onEnable() {
      super.onEnable();
   }

   @Override
   public void tick() {
      if (this.mc.field_1724 != null
         && this.mc.field_1724.method_24828()
         && GLFW.glfwGetKey(this.mc.method_22683().method_4490(), 32) == 1
         && !InteractionUtil.isChatOpen()) {
         this.mc.field_1724.method_6043();
      }
   }

   @Override
   public void onDisable() {
      super.onDisable();
   }
}
