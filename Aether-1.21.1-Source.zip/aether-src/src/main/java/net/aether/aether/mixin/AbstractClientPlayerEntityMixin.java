package net.aether.aether.mixin;

import net.aether.aether.module.ModuleManager;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_742;
import net.minecraft.class_8685;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_742.class})
@Environment(EnvType.CLIENT)
public class AbstractClientPlayerEntityMixin {
   private static final class_2960 CAPE_ID = class_2960.method_60655("aether", "textures/cape.png");

   @Inject(
      at = {@At("RETURN")},
      method = {"getSkinTextures"},
      cancellable = true
   )
   private void getSkinTextures(CallbackInfoReturnable<class_8685> cir) {
      if (ModuleManager.INSTANCE.getModuleByName("Cape").enabled) {
         class_8685 textures = (class_8685)cir.getReturnValue();
         cir.setReturnValue(
            new class_8685(textures.comp_1626(), textures.comp_1911(), CAPE_ID, textures.comp_1628(), textures.comp_1629(), textures.comp_1630())
         );
      } else {
         class_8685 textures = (class_8685)cir.getReturnValue();
         cir.setReturnValue(
            new class_8685(textures.comp_1626(), textures.comp_1911(), textures.comp_1627(), textures.comp_1628(), textures.comp_1629(), textures.comp_1630())
         );
      }
   }
}
