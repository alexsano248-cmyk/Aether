package net.aether.aether.module;

import java.util.ArrayList;
import net.aether.aether.module.settings.BooleanSetting;
import net.aether.aether.module.settings.KeycodeSetting;
import net.aether.aether.module.settings.Setting;
import net.aether.aether.ui.ModulesListOverlay;
import net.minecraft.class_1313;
import net.minecraft.class_243;
import net.minecraft.class_310;

public abstract class Module {
   protected static class_310 mc = class_310.method_1551();
   public String name;
   public String description;
   public Category category;
   public boolean enabled;
   public ArrayList<Setting> settings;
   public boolean showEditButton;
   public boolean blatant;
   public BooleanSetting showInModulesList = new BooleanSetting("Show in Modules List", true);
   public KeycodeSetting keybind = new KeycodeSetting("Keybind", 0);

   public Module(String name, String description, Category category, boolean blatant) {
      this.name = name;
      this.description = description;
      this.category = category;
      this.blatant = blatant;
      this.settings = new ArrayList<>();
      this.settings.add(this.showInModulesList);
      this.settings.add(this.keybind);
   }

   public void onEnable() {
      ModulesListOverlay.INSTANCE.update();
   }

   public void onDisable() {
      ModulesListOverlay.INSTANCE.update();
   }

   public void onMotion(class_1313 type, class_243 movement) {
   }

   public void tick() {
   }

   public void toggle() {
      this.enabled = !this.enabled;
      if (this.enabled) {
         this.onEnable();
      } else {
         this.onDisable();
      }
   }

   public Setting getSettingByName(String settingName) {
      for (Setting setting : this.settings) {
         if (setting.name.trim().equalsIgnoreCase(settingName)) {
            return setting;
         }
      }

      return null;
   }

   protected void addSettings(Setting... settings) {
      for (Setting setting : settings) {
         this.settings.add(setting);
      }
   }
}
