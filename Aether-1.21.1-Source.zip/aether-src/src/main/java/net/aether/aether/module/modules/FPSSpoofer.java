package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.BooleanSetting;
import net.aether.aether.module.settings.DoubleSetting;

public class FPSSpoofer extends Module {
   public static FPSSpoofer INSTANCE;
   public final DoubleSetting fakeFps = new DoubleSetting("Fake FPS", 69.0, 0.0, 1000.0, 0);
   public final BooleanSetting fluctuate = new BooleanSetting("Fluctuate", false);
   public final DoubleSetting fluctuateAmount = new DoubleSetting("Fluct Amount", 20.0, 0.0, 100.0, 0);

   public FPSSpoofer() {
      super("FPS Spoofer", "Sets your FPS to a number", Category.RENDER, false);
      this.settings.add(this.fakeFps);
      this.settings.add(this.fluctuate);
      this.settings.add(this.fluctuateAmount);
      INSTANCE = this;
   }
}
