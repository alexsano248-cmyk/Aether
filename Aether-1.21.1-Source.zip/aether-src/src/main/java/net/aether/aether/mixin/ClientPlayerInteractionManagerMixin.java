package net.aether.aether.mixin;

import net.aether.aether.module.ModuleManager;
import net.aether.aether.module.modules.FastMine;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin({class_636.class})
public class ClientPlayerInteractionManagerMixin {
   @ModifyConstant(
      method = {"updateBlockBreakingProgress"},
      constant = {@Constant(
         intValue = 5
      )}
   )
   private int modifyBlockBreakingProgress(int original) {
      FastMine fastMine = (FastMine)ModuleManager.INSTANCE.getModuleByName("Fast Mine");
      if (fastMine != null && fastMine.enabled && fastMine.shouldFastMine()) {
         String var3 = fastMine.mode.value;
         switch (var3) {
            case "Instant":
               return 0;
            case "Fast":
               return 1;
            case "Custom":
               return (int)(5.0 / fastMine.speed.value);
            default:
               return original;
         }
      } else {
         return original;
      }
   }
}
