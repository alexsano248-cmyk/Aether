package net.aether.aether.ui.hud.editor;

import java.util.ArrayList;
import net.aether.aether.ui.hud.HUDModule;
import net.aether.aether.ui.hud.HUDModuleManager;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class HUDModuleList {
   public int x;
   public int y;
   public int height;
   public int width = 128;
   int startX;
   int startY;
   boolean dragging = false;
   public boolean collapsed = false;
   ArrayList<HUDModuleButton> buttons;

   public HUDModuleList(int initialX, int initialY, boolean collapsed) {
      this.x = initialX;
      this.y = initialY;
      this.collapsed = collapsed;
      this.buttons = new ArrayList<>();

      for (HUDModule m : HUDModuleManager.INSTANCE.modules) {
         this.buttons.add(new HUDModuleButton(m));
      }

      if (this.buttons.size() == 0) {
         collapsed = true;
      }

      this.height = this.buttons.size() * 12 + 18;
   }

   public void render(class_332 drawContext, int mouseX, int mouseY, float delta, class_327 textRenderer) {
      if (this.dragging) {
         this.x = mouseX - this.startX;
         this.y = mouseY - this.startY;
      }

      drawContext.method_25294(this.x, this.y, this.x + this.width, this.collapsed ? this.y + 16 : this.y + this.height, -11141121);
      drawContext.method_25294(this.x + 2, this.y + 2, this.x + (this.width - 2), this.y + 14, this.hovered(mouseX, mouseY) ? -13421773 : -14540254);
      drawContext.method_52706(class_2960.method_60655("aether", "hud"), this.x + 2, this.y + 2, 12, 12);
      drawContext.method_51433(textRenderer, "HUD Modules", this.x + 16, this.y + 4, -1, false);
      if (!this.collapsed) {
         int buttonYOffset = this.y + 16;

         for (HUDModuleButton m : this.buttons) {
            m.render(drawContext, mouseX, mouseY, this.x + 2, buttonYOffset, textRenderer);
            buttonYOffset += 12;
         }
      }
   }

   public boolean hovered(int mouseX, int mouseY) {
      return mouseX >= this.x + 2 && mouseX <= this.x + (this.width - 2) && mouseY >= this.y + 2 && mouseY <= this.y + 14;
   }

   public void mouseClicked(int mouseX, int mouseY, int button) {
      for (HUDModuleButton moduleButton : this.buttons) {
         if (moduleButton.mouseClicked(mouseX, mouseY, button)) {
            return;
         }
      }

      if (this.hovered(mouseX, mouseY) && button == 1) {
         this.collapsed = !this.collapsed;
      } else if (this.hovered(mouseX, mouseY) && button == 0) {
         this.startX = mouseX - this.x;
         this.startY = mouseY - this.y;
         this.dragging = true;
      }
   }

   public void mouseReleased(int mouseX, int mouseY, int button) {
      this.dragging = false;
   }
}
