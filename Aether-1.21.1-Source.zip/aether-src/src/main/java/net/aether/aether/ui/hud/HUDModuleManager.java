package net.aether.aether.ui.hud;

import java.util.ArrayList;
import net.aether.aether.ui.hud.modules.ArmorDisplay;
import net.aether.aether.ui.hud.modules.CPSDetector;
import net.aether.aether.ui.hud.modules.ClientTag;
import net.aether.aether.ui.hud.modules.Coordinates;
import net.aether.aether.ui.hud.modules.FPS;
import net.aether.aether.ui.hud.modules.MovementSpeed;
import net.aether.aether.ui.hud.modules.Ping;
import net.aether.aether.ui.hud.modules.ServerInfoHUD;
import net.aether.aether.ui.hud.modules.TPS;
import net.aether.aether.ui.hud.modules.TotemCounter;

public class HUDModuleManager {
   public static HUDModuleManager INSTANCE = new HUDModuleManager();
   public ArrayList<HUDModule> modules = new ArrayList<>();

   public HUDModuleManager() {
      this.registerModules(
         new ClientTag(2, 2),
         new FPS(2, 12),
         new CPSDetector(2, 22),
         new TPS(2, 32),
         new Ping(2, 42),
         new ServerInfoHUD(2, 72),
         new Coordinates(2, 62),
         new MovementSpeed(2, 52),
         new ArmorDisplay(2, 82),
         new TotemCounter(20, 82)
      );
   }

   private void registerModules(HUDModule... modules) {
      for (HUDModule module : modules) {
         this.modules.add(module);
      }
   }

   public HUDModule getModuleByName(String moduleName) {
      for (HUDModule module : this.modules) {
         if (module.name.trim().equalsIgnoreCase(moduleName)) {
            return module;
         }
      }

      return null;
   }

   public ArrayList<HUDModule> getEnabledModules() {
      ArrayList<HUDModule> enabledModules = new ArrayList<>();

      for (HUDModule module : this.modules) {
         if (module.enabled) {
            enabledModules.add(module);
         }
      }

      return enabledModules;
   }
}
