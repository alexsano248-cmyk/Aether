package net.aether.aether.util;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class ReflectionUtils {
   public static Method tryGetMethod(String methodName, Class<?> class1) {
      try {
         return class1.getDeclaredMethod(methodName);
      } catch (Exception var3) {
         var3.printStackTrace();
         return (Method)null;
      }
   }

   public static void tryCallMethod(Method method, Object... parameters) {
      try {
         method.invoke(null, parameters);
      } catch (Exception var3) {
         var3.printStackTrace();
      }
   }

   public static Object getPrivateField(Class<?> clazz, Object instance, String fieldName) throws Exception {
      Field field = clazz.getDeclaredField(fieldName);
      field.setAccessible(true);
      return field.get(instance);
   }

   public static void setPrivateField(Class<?> clazz, Object instance, String fieldName, Object value) throws Exception {
      Field field = clazz.getDeclaredField(fieldName);
      field.setAccessible(true);
      field.set(instance, value);
   }
}
