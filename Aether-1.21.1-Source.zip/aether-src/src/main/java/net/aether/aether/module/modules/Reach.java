package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.DoubleSetting;
import net.minecraft.class_5134;

public class Reach extends Module {
   DoubleSetting blockRange = new DoubleSetting("Block Range", 4.5, 1.0, 10.0, 1);
   DoubleSetting entityRange = new DoubleSetting("Entity Range", 3.0, 1.0, 10.0, 1);
   double oldBe = 4.5;
   double oldEe = 3.0;

   public Reach() {
      super("Reach", "Extends player interaction distance.", Category.COMBAT, true);
      this.settings.add(this.blockRange);
      this.settings.add(this.entityRange);
   }

   @Override
   public void onEnable() {
      super.onEnable();
      this.oldBe = mc.field_1724.method_5996(class_5134.field_47758).method_6201();
      this.oldEe = mc.field_1724.method_5996(class_5134.field_47759).method_6201();
   }

   @Override
   public void tick() {
      mc.field_1724.method_5996(class_5134.field_47758).method_6192(this.blockRange.value);
      mc.field_1724.method_5996(class_5134.field_47759).method_6192(this.entityRange.value);
   }

   @Override
   public void onDisable() {
      super.onDisable();
      mc.field_1724.method_5996(class_5134.field_47758).method_6192(this.oldBe);
      mc.field_1724.method_5996(class_5134.field_47759).method_6192(this.oldEe);
   }
}
