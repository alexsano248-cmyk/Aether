package net.aether.aether.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_2172;
import net.minecraft.class_310;
import org.apache.commons.lang3.StringUtils;

public abstract class Command {
   protected static class_310 mc;
   private final String name;
   private final String description;
   private final List<String> aliases = new ArrayList<>();
   public int SINGLE_SUCCESS = 1;

   public Command(String name, String description, String... aliases) {
      this.name = name;
      this.description = description;
      Collections.addAll(this.aliases, aliases);
      mc = class_310.method_1551();
   }

   protected static <T> RequiredArgumentBuilder<class_2172, T> argument(String name, ArgumentType<T> type) {
      return RequiredArgumentBuilder.argument(name, type);
   }

   protected static LiteralArgumentBuilder<class_2172> literal(String name) {
      return LiteralArgumentBuilder.literal(name);
   }

   public final void registerTo(CommandDispatcher<class_2172> dispatcher) {
      this.register(dispatcher, this.name);

      for (String alias : this.aliases) {
         this.register(dispatcher, alias);
      }
   }

   public void register(CommandDispatcher<class_2172> dispatcher, String name) {
      LiteralArgumentBuilder<class_2172> builder = LiteralArgumentBuilder.literal(name);
      this.build(builder);
      dispatcher.register(builder);
   }

   public abstract void build(LiteralArgumentBuilder<class_2172> var1);

   public String getName() {
      return this.name;
   }

   public String getDescription() {
      return this.description;
   }

   public List<String> getAliases() {
      return this.aliases;
   }

   @Override
   public String toString() {
      return CommandManager.get().getPrefix() + this.name;
   }

   public String toString(String... args) {
      StringBuilder base = new StringBuilder(this.toString());

      for (String arg : args) {
         base.append(' ').append(arg);
      }

      return base.toString();
   }

   public static String nameToTitle(String name) {
      return Arrays.stream(name.split("-")).<CharSequence>map(StringUtils::capitalize).collect(Collectors.joining(" "));
   }
}
