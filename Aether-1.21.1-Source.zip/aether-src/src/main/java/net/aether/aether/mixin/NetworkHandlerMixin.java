package net.aether.aether.mixin;

import net.aether.aether.event.EventBus;
import net.aether.aether.event.events.GameJoinedEvent;
import net.aether.aether.event.events.PacketEvent;
import net.minecraft.class_2678;
import net.minecraft.class_2761;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_634.class})
public class NetworkHandlerMixin {
   @Inject(
      method = {"onWorldTimeUpdate"},
      at = {@At("HEAD")}
   )
   private void onWorldTimeUpdate(class_2761 packet, CallbackInfo ci) {
      EventBus.post(new PacketEvent.Receive(packet));
   }

   @Inject(
      method = {"onGameJoin"},
      at = {@At("HEAD")}
   )
   private void onGameJoin(class_2678 packet, CallbackInfo ci) {
      EventBus.post(new GameJoinedEvent());
   }
}
