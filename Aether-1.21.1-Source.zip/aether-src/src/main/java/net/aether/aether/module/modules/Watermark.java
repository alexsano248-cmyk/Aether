package net.aether.aether.module.modules;

import net.aether.aether.Aether;
import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.BooleanSetting;
import net.aether.aether.module.settings.DropdownSetting;
import net.aether.aether.module.settings.IndexSetting;
import net.minecraft.class_124;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class Watermark extends Module {
   public final DropdownSetting font = new DropdownSetting("Font", "Default", new String[]{"Default", "Alt", "Galactic"});
   public final IndexSetting color = new IndexSetting("Color",
      new String[]{"White","Aqua","LightPurple","Gold","Green","Red","Yellow"}, 1);
   public final BooleanSetting shadow = new BooleanSetting("Shadow", true);
   public final BooleanSetting showFps = new BooleanSetting("Show FPS", true);
   public final BooleanSetting showUser = new BooleanSetting("Show User", true);

   public Watermark() {
      super("Watermark", "Renders the Aether watermark on screen.", Category.RENDER, false);
      this.enabled = true;
      this.settings.add(this.font);
      this.settings.add(this.color);
      this.settings.add(this.shadow);
      this.settings.add(this.showFps);
      this.settings.add(this.showUser);
   }

   public int getColor() {
      switch (this.color.getValue()) {
         case "Aqua": return class_124.field_1075.method_532();
         case "LightPurple": return class_124.field_1078.method_532();
         case "Gold": return class_124.field_1065.method_532();
         case "Green": return class_124.field_1060.method_532();
         case "Red": return class_124.field_1061.method_532();
         case "Yellow": return class_124.field_1054.method_532();
         default: return 0xFFFFFFFF;
      }
   }

   public void render(class_332 ctx) {
      if (!this.enabled) return;
      class_310 mc = class_310.method_1551();
      class_327 fr = mc.field_1772;
      StringBuilder sb = new StringBuilder("Aether ").append(Aether.VERSION);
      if (this.showUser.value && mc.field_1724 != null) sb.append(" \u00A78| \u00A7r").append(mc.field_1724.method_5477().getString());
      if (this.showFps.value) sb.append(" \u00A78| \u00A7r").append(mc.method_47599()).append(" FPS");
      int c = (this.color.getValue().equals("White") ? 0xFFFFFFFF : (0xFF000000 | (getColor() & 0xFFFFFF)));
      ctx.method_51439(fr, net.minecraft.class_2561.method_43470(sb.toString()), 4, 4, c, this.shadow.value);
   }
}
