package net.aether.aether.command.commands;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.aether.aether.command.Command;
import net.minecraft.class_1297;
import net.minecraft.class_2172;
import net.minecraft.class_746;

public class Teleport extends Command {
   public Teleport() {
      super("teleport", "Teleports you to specified coordinates.");
   }

   @Override
   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(
         argument("x", DoubleArgumentType.doubleArg())
            .then(argument("y", DoubleArgumentType.doubleArg()).then(argument("z", DoubleArgumentType.doubleArg()).executes(context -> {
               class_746 player = mc.field_1724;

               assert player != null;

               double x = (Double)context.getArgument("x", Double.class);
               double y = (Double)context.getArgument("y", Double.class);
               double z = (Double)context.getArgument("z", Double.class);
               if (player.method_5765()) {
                  class_1297 vehicle = player.method_5854();
                  vehicle.method_5814(x, y, z);
               }

               player.method_5814(x, y, z);
               return this.SINGLE_SUCCESS;
            })))
      );
   }
}
