package net.aether.aether.command.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.aether.aether.command.Command;
import net.aether.aether.util.ChatUtils;
import net.aether.aether.util.ColorUtils;
import net.aether.aether.util.InteractionUtil;
import net.minecraft.class_2172;

public class CenterPos extends Command {
   public CenterPos() {
      super("center", "Centeres your position on the block.");
   }

   @Override
   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.executes(context -> {
         ChatUtils.sendMsg(ColorUtils.aqua + "Centered your position.");
         InteractionUtil.centerPlayer();
         return this.SINGLE_SUCCESS;
      });
   }
}
