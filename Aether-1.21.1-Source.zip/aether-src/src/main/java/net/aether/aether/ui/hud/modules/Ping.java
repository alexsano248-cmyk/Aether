package net.aether.aether.ui.hud.modules;

import net.aether.aether.ui.hud.HUDModule;
import net.aether.aether.util.ColorUtils;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_640;

public class Ping extends HUDModule {
   public Ping(int x, int y) {
      super("Ping", x, y);
      this.width = 48;
      this.height = 8;
      this.enabled = true;
   }

   @Override
   public void render(class_332 drawContext, int mouseX, int mouseY, class_327 textRenderer, boolean editMode, boolean enabled) {
      super.render(drawContext, mouseX, mouseY, textRenderer, editMode, enabled);
      class_640 player = class_310.method_1551().method_1562().method_2871(class_310.method_1551().field_1724.method_5667());
      if (player != null) {
         drawContext.method_25303(mc.field_1772, "Ping: " + ColorUtils.white + player.method_2959(), this.x, this.y, -11141121);
      } else {
         drawContext.method_25303(mc.field_1772, "Ping: " + ColorUtils.red + "Unknown", this.x, this.y, -11141121);
      }
   }
}
