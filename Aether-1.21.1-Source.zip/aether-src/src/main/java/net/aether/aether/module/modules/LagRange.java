package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.DoubleSetting;
import net.minecraft.class_2828;
import net.minecraft.class_243;

public class LagRange extends Module {
   public final DoubleSetting range = new DoubleSetting("Range", 5.0, 1.0, 15.0, 1);
   private class_243 origin = null;
   private int ticks = 0;

   public LagRange() {
      super("LagRange", "Holds position packets to lag-back hit registration.", Category.COMBAT, true);
   }

   @Override
   public void onEnable() {
      super.onEnable();
      if (mc.field_1724 != null) this.origin = mc.field_1724.method_19538();
      this.ticks = 0;
   }

   @Override
   public void tick() {
      if (mc.field_1724 == null || origin == null) return;
      this.ticks++;
      if (mc.field_1724.method_19538().method_1022(origin) > this.range.value) {
         // Return to origin via fake packet
         mc.method_1562().method_52787(new class_2828.class_2829(
            origin.field_1352, origin.field_1351, origin.field_1350, mc.field_1724.method_5765()));
      }
   }

   @Override
   public void onDisable() {
      super.onDisable();
      this.origin = null;
   }
}
