package net.aether.aether.mixin;

import net.aether.aether.module.ModuleManager;
import net.aether.aether.module.modules.Render;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_702;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_702.class})
public class ParticleManagerMixin {
   @Inject(
      method = {"addParticle"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onAddParticle(
      class_2394 effect, double x, double y, double z, double velocityX, double velocityY, double velocityZ, CallbackInfoReturnable<Boolean> cir
   ) {
      if (effect != null) {
         Render render = (Render)ModuleManager.INSTANCE.getModuleByName("NoRender");
         if (render != null
            && render.enabled
            && render.explosions.value
            && (
               effect.method_10295() == class_2398.field_11236
                  || effect.method_10295() == class_2398.field_11221
                  || effect.method_10295() == class_2398.field_11237
            )) {
            cir.setReturnValue(false);
            cir.cancel();
         }
      }
   }
}
