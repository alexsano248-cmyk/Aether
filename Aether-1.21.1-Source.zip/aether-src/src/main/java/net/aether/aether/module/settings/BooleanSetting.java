package net.aether.aether.module.settings;

import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class BooleanSetting extends Setting {
   public boolean value;

   public BooleanSetting(String name, boolean value) {
      this.name = name;
      this.value = value;
   }

   @Override
   public void render(class_332 drawContext, int x, int y, int mouseX, int mouseY, class_327 textRenderer) {
      super.render(drawContext, x, y, mouseX, mouseY, textRenderer);
      drawContext.method_27535(textRenderer, class_2561.method_43470(this.name), x + 8, y + 10, 16777215);
      int toggleX = x + 170;
      int toggleY = y + 8;
      this.drawRectangleWithRoundedCorners(drawContext, toggleX, toggleY, toggleX + 28, toggleY + 12, 6, -11184811);
      if (this.value) {
         this.drawRectangleWithRoundedCorners(drawContext, toggleX + 16, toggleY, toggleX + 28, toggleY + 12, 6, -11141121);
      } else {
         this.drawRectangleWithRoundedCorners(drawContext, toggleX, toggleY, toggleX + 12, toggleY + 12, 6, -8947849);
      }
   }

   private void drawRectangleWithRoundedCorners(class_332 drawContext, int x1, int y1, int x2, int y2, int radius, int color) {
      drawContext.method_25294(x1 + radius, y1, x2 - radius, y2, color);
      drawContext.method_25294(x1, y1 + radius, x2, y2 - radius, color);
      this.drawCircle(drawContext, x1 + radius, y1 + radius, radius, color);
      this.drawCircle(drawContext, x2 - radius, y1 + radius, radius, color);
      this.drawCircle(drawContext, x1 + radius, y2 - radius, radius, color);
      this.drawCircle(drawContext, x2 - radius, y2 - radius, radius, color);
   }

   private void drawCircle(class_332 drawContext, int centerX, int centerY, int radius, int color) {
      for (int y = -radius; y <= radius; y++) {
         for (int x = -radius; x <= radius; x++) {
            if (x * x + y * y <= radius * radius) {
               drawContext.method_25294(centerX + x, centerY + y, centerX + x + 1, centerY + y + 1, color);
            }
         }
      }
   }

   @Override
   public void mouseClicked(double mouseX, double mouseY, int button) {
      if (this.hovered((int)mouseX, (int)mouseY) && button == 0) {
         this.value = !this.value;
      }
   }
}
