package net.aether.aether.util;

import java.util.Arrays;
import net.aether.aether.event.Event;
import net.aether.aether.event.EventBus;
import net.aether.aether.event.events.GameJoinedEvent;
import net.aether.aether.event.events.PacketEvent;
import net.minecraft.class_2761;

public class TickRateUtil {
   public static TickRateUtil INSTANCE = new TickRateUtil();
   private final float[] tickRates = new float[20];
   private int nextIndex = 0;
   private long timeLastTimeUpdate = -1L;
   private long timeGameJoined;

   public TickRateUtil() {
      EventBus.register(this);
   }

   @Event.EventHandler
   public void onReceivePacket(PacketEvent.Receive event) {
      if (event.packet instanceof class_2761) {
         long now = System.currentTimeMillis();
         if (this.timeLastTimeUpdate != -1L) {
            float timeElapsed = (float)(now - this.timeLastTimeUpdate) / 1000.0F;
            this.tickRates[this.nextIndex] = Math.min(20.0F, 20.0F / timeElapsed);
            this.nextIndex = (this.nextIndex + 1) % this.tickRates.length;
         }

         this.timeLastTimeUpdate = now;
      }
   }

   @Event.EventHandler
   public void onGameJoined(GameJoinedEvent event) {
      Arrays.fill(this.tickRates, 0.0F);
      this.nextIndex = 0;
      this.timeGameJoined = this.timeLastTimeUpdate = System.currentTimeMillis();
   }

   public float getTickRate() {
      if (System.currentTimeMillis() - this.timeGameJoined < 4000L) {
         return 20.0F;
      } else {
         int numTicks = 0;
         float sumTickRates = 0.0F;

         for (float tickRate : this.tickRates) {
            if (tickRate > 0.0F) {
               sumTickRates += tickRate;
               numTicks++;
            }
         }

         return numTicks > 0 ? sumTickRates / (float)numTicks : 0.0F;
      }
   }
}
