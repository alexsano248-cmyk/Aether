package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.BooleanSetting;

public class Render extends Module {
   public final BooleanSetting explosions = new BooleanSetting("Explosions", false);
   public final BooleanSetting items = new BooleanSetting("Items", false);
   public final BooleanSetting crystals = new BooleanSetting("Crystals", false);

   public Render() {
      super("NoRender", "Prevents certain renders from happening.", Category.RENDER, true);
      this.settings.add(this.explosions);
      this.settings.add(this.items);
      this.settings.add(this.crystals);
   }
}
