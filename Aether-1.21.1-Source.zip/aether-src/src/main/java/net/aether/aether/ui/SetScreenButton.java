package net.aether.aether.ui;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class SetScreenButton {
   String text;
   class_437 screen;
   int x;
   int y;
   int color;
   int width;

   public SetScreenButton(String text, int x, int y, int color, class_437 screen) {
      this.text = text;
      this.x = x;
      this.y = y;
      this.color = color;
      this.screen = screen;
   }

   public void render(class_332 drawContext, class_327 textRenderer, int mouseX, int mouseY, int x, int y) {
      this.x = x;
      this.y = y;
      this.width = textRenderer.method_1727(this.text);
      drawContext.method_25294(x - 1, y - 1, x + this.width + 1, y + 10, this.hovered(mouseX, mouseY) ? 1442840575 : 0);
      drawContext.method_51439(textRenderer, class_2561.method_43470(this.text), x, y, this.color, true);
   }

   public boolean hovered(int mouseX, int mouseY) {
      return mouseX >= this.x && mouseX <= this.x + this.width && mouseY >= this.y && mouseY <= this.y + 10;
   }

   public void mouseClicked(int mouseX, int mouseY) {
      if (this.hovered(mouseX, mouseY)) {
         class_310.method_1551().method_1507(this.screen);
      }
   }
}
