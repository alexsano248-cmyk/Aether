package net.aether.aether.util;

import java.util.Arrays;
import java.util.List;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class AuthUtil {
   private static final List<String> AUTHORIZED_PLAYERS = Arrays.asList(
      "Aether Team", "anchormacroer", "EasterDefinesqui", "velatonin", "Cottontailtoho", "Bm6n", "Cyclone_XD", "bl4k101"
   );

   public static boolean isAuthorized() {
      if (class_310.method_1551().field_1724 == null) {
         return false;
      } else {
         String username = class_310.method_1551().field_1724.method_5477().getString().toLowerCase();
         return AUTHORIZED_PLAYERS.stream().anyMatch(auth -> auth.toLowerCase().equals(username));
      }
   }

   public static class UnauthorizedScreen extends class_437 {
      public UnauthorizedScreen() {
         super(class_2561.method_43470("Unauthorized Access"));
      }

      protected void method_25426() {
         super.method_25426();
         int centerX = this.field_22789 / 2;
         int centerY = this.field_22790 / 2;
         this.method_37063(class_4185.method_46430(class_2561.method_43470("Unauthorized Access"), button -> {
         }).method_46434(centerX - 100, centerY - 60, 200, 20).method_46431());
         this.method_37063(class_4185.method_46430(class_2561.method_43470("You are not authorized to use Aether Client"), button -> {
         }).method_46434(centerX - 150, centerY - 20, 300, 20).method_46431());
         this.method_37063(
            class_4185.method_46430(
                  class_2561.method_43470("Contact Aether Team on Discord"),
                  button -> class_156.method_668().method_670("https://discord.com/users/1306686420190236753")
               )
               .method_46434(centerX - 100, centerY + 20, 200, 20)
               .method_46431()
         );
         this.method_37063(
            class_4185.method_46430(class_2561.method_43470("Exit"), button -> class_310.method_1551().method_1592())
               .method_46434(centerX - 100, centerY + 60, 200, 20)
               .method_46431()
         );
      }

      public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
         this.method_25420(context, mouseX, mouseY, delta);
         super.method_25394(context, mouseX, mouseY, delta);
      }

      public boolean method_25421() {
         return true;
      }
   }
}
