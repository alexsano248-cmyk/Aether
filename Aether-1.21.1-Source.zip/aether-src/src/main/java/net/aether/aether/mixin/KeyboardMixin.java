package net.aether.aether.mixin;

import net.aether.aether.module.Module;
import net.aether.aether.module.ModuleManager;
import net.aether.aether.ui.clickgui.ClickGUIScreen;
import net.aether.aether.util.InteractionUtil;
import net.aether.aether.util.KeycodeUtils;
import net.minecraft.class_309;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_309.class})
public abstract class KeyboardMixin {
   @Shadow
   @Final
   private class_310 field_1678;

   @Inject(
      method = {"onKey"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void onKey(long window, int key, int scancode, int action, int modifiers, CallbackInfo info) {
      if (KeycodeUtils.isKeyPressed(ClickGUIScreen.keybind) && !InteractionUtil.isChatOpen()) {
         class_310.method_1551().method_1507(ClickGUIScreen.INSTANCE);
      }

      for (Module m : ModuleManager.INSTANCE.modules) {
         if (key == m.keybind.value && action == 1 && class_310.method_1551().field_1755 == null) {
            m.toggle();
         }
      }
   }
}
