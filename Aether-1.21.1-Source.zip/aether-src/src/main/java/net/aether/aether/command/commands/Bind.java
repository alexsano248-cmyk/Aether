package net.aether.aether.command.commands;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.aether.aether.command.Command;
import net.aether.aether.ui.clickgui.ClickGUIScreen;
import net.aether.aether.util.ChatUtils;
import net.minecraft.class_2172;

public class Bind extends Command {
   public Bind() {
      super("bind", "Binds clickgui");
   }

   @Override
   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(argument("key", StringArgumentType.string()).executes(context -> {
         String key = StringArgumentType.getString(context, "key");
         key = key.replace("_", " ");
         ClickGUIScreen.keybind = key;
         ChatUtils.sendMsg("ClickGUI keybind set to §d" + key);
         return this.SINGLE_SUCCESS;
      }));
   }
}
