package net.aether.aether.ui.clickgui;

import java.util.ArrayList;
import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.ModuleManager;
import net.aether.aether.util.MathUtils;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import org.lwjgl.glfw.GLFW;

public class CategoryPane {
   public Category category;
   public int x;
   public int y;
   public int height;
   public int width = 96;
   int startX;
   int startY;
   boolean dragging = false;
   public boolean collapsed = false;
   ArrayList<ModuleButton> moduleButtons;
   class_2960 icon;
   private float animationProgress = 0.0F;
   private static final float ANIMATION_SPEED = 0.5F;
   private float dragX = 0.0F;
   private float dragY = 0.0F;
   private static final float DRAG_SMOOTHING = 0.3F;
   private int targetX;
   private int targetY;
   private boolean isDragging = false;
   private int dragOffsetX;
   private int dragOffsetY;

   public CategoryPane(Category category, int initialX, int initialY, boolean collapsed) {
      this.category = category;
      this.x = initialX;
      this.y = initialY;
      this.targetX = initialX;
      this.targetY = initialY;
      this.collapsed = collapsed;
      this.animationProgress = collapsed ? 0.0F : 1.0F;
      this.moduleButtons = new ArrayList<>();
      this.icon = class_2960.method_60655("aether", category.name.toLowerCase());

      for (Module m : ModuleManager.INSTANCE.getModulesByCategory(category)) {
         this.moduleButtons.add(new ModuleButton(m));
      }

      if (this.moduleButtons.size() == 0) {
         collapsed = true;
      }

      this.height = this.moduleButtons.size() * 16 + 24;
   }

   public void renderRoundedRect(class_332 drawContext, int x, int y, int width, int height, int color, int radius) {
      int shadowColor = 1073741824;
      drawContext.method_25294(x + 2, y + 2, x + width - 2, y + height, shadowColor);
      drawContext.method_25294(x + radius, y, x + width - radius, y + height, color);
      drawContext.method_25294(x, y + radius, x + radius, y + height - radius, color);
      drawContext.method_25294(x + width - radius, y + radius, x + width, y + height - radius, color);
      this.drawFilledCircle(drawContext, x + radius, y + radius, radius, color);
      this.drawFilledCircle(drawContext, x + width - radius - 1, y + radius, radius, color);
      this.drawFilledCircle(drawContext, x + radius, y + height - radius - 1, radius, color);
      this.drawFilledCircle(drawContext, x + width - radius - 1, y + height - radius - 1, radius, color);
   }

   private void drawFilledCircle(class_332 drawContext, int centerX, int centerY, int radius, int color) {
      int squareRadius = radius * radius;

      for (int x = -radius; x <= radius; x++) {
         for (int y = -radius; y <= radius; y++) {
            if (x * x + y * y <= squareRadius) {
               drawContext.method_25294(centerX + x, centerY + y, centerX + x + 1, centerY + y + 1, color);
            }
         }
      }
   }

   private boolean isMousePressed() {
      long windowHandle = class_310.method_1551().method_22683().method_4490();
      return GLFW.glfwGetMouseButton(windowHandle, 0) == 1;
   }

   public void render(class_332 drawContext, int mouseX, int mouseY, float delta, class_327 textRenderer) {
      float targetProgress = this.collapsed ? 0.0F : 1.0F;
      if (this.animationProgress != targetProgress) {
         this.animationProgress = MathUtils.lerp(this.animationProgress, targetProgress, 0.5F);
      }

      if (this.isDragging) {
         this.targetX = mouseX - this.dragOffsetX;
         this.targetY = mouseY - this.dragOffsetY;
      }

      if (this.x != this.targetX || this.y != this.targetY) {
         this.x = (int)MathUtils.lerp((float)this.x, (float)this.targetX, 0.3F);
         this.y = (int)MathUtils.lerp((float)this.y, (float)this.targetY, 0.3F);
      }

      int backgroundColor = -15066598;
      int highlightColor = this.hovered(mouseX, mouseY) ? -13816531 : -14342875;
      int borderColor = -12763843;
      if (this.isMousePressed()) {
         this.onMousePressed(mouseX, mouseY);
      } else {
         this.onMouseReleased();
      }

      int currentHeight = (int)(20.0F + (float)(this.height - 20) * this.animationProgress);
      this.renderRoundedRect(drawContext, this.x, this.y, this.width, currentHeight, backgroundColor, 5);
      this.renderRoundedRect(drawContext, this.x + 2, this.y + 2, this.width - 4, 16, highlightColor, 5);
      drawContext.method_25294(this.x + 1, this.y + 1, this.x + this.width - 1, this.y + 2, borderColor);
      drawContext.method_25294(this.x + 1, this.y + currentHeight - 2, this.x + this.width - 1, this.y + currentHeight - 1, borderColor);
      drawContext.method_25294(this.x + 1, this.y + 2, this.x + 2, this.y + currentHeight - 2, borderColor);
      drawContext.method_25294(this.x + this.width - 2, this.y + 2, this.x + this.width - 1, this.y + currentHeight - 2, borderColor);
      drawContext.method_52706(this.icon, this.x + 4, this.y + 4, 12, 12);
      drawContext.method_51433(textRenderer, this.category.name, this.x + 20, this.y + 4, -1, false);
      String indicator = this.collapsed ? "▼" : "▲";
      drawContext.method_51433(textRenderer, indicator, this.x + this.width - 16, this.y + 4, -1, false);
      if (!this.collapsed && this.animationProgress > 0.99F) {
         int buttonYOffset = this.y + 20;

         for (ModuleButton m : this.moduleButtons) {
            if (ModuleManager.isBlatantMode() || !m.module.blatant) {
               m.render(drawContext, mouseX, mouseY, this.x + 4, buttonYOffset, textRenderer);
               buttonYOffset += 16;
            }
         }
      }
   }

   public void renderTooltips(class_332 drawContext, int mouseX, int mouseY, class_327 textRenderer) {
      if (!this.collapsed && this.animationProgress > 0.99F) {
         for (ModuleButton m : this.moduleButtons) {
            if (ModuleManager.isBlatantMode() || !m.module.blatant) {
               m.renderTooltip(drawContext, mouseX, mouseY, textRenderer);
            }
         }
      }
   }

   public void onMousePressed(int mouseX, int mouseY) {
      if (this.hovered(mouseX, mouseY)) {
         this.isDragging = true;
         this.dragOffsetX = mouseX - this.x;
         this.dragOffsetY = mouseY - this.y;
         this.targetX = this.x;
         this.targetY = this.y;
      }
   }

   public void onMouseReleased() {
      this.isDragging = false;
   }

   public void onMouseDragged(int mouseX, int mouseY) {
      if (this.isDragging) {
         this.targetX = mouseX - this.dragOffsetX;
         this.targetY = mouseY - this.dragOffsetY;
      }
   }

   public boolean hovered(int mouseX, int mouseY) {
      return mouseX >= this.x + 2 && mouseX <= this.x + (this.width - 2) && mouseY >= this.y + 2 && mouseY <= this.y + 18;
   }

   public void mouseClicked(int mouseX, int mouseY, int button) {
      for (ModuleButton moduleButton : this.moduleButtons) {
         if (moduleButton.mouseClicked(mouseX, mouseY, button)) {
            return;
         }
      }

      if (this.hovered(mouseX, mouseY)) {
         if (button == 1) {
            this.collapsed = !this.collapsed;
         } else if (button == 0) {
            this.startX = mouseX - this.x;
            this.startY = mouseY - this.y;
            this.dragging = true;
            this.targetX = this.x;
            this.targetY = this.y;
         }
      }
   }

   public void mouseReleased(int mouseX, int mouseY, int button) {
      this.dragging = false;
   }
}
