package net.aether.aether.util;

public class ColorUtils {
   public static String colorChar = "§";
   public static String black = "§0";
   public static String darkBlue = "§1";
   public static String darkGreen = "§2";
   public static String darkAqua = "§3";
   public static String darkRed = "§4";
   public static String darkMagenta = "§5";
   public static String gold = "§6";
   public static String gray = "§7";
   public static String darkGray = "§8";
   public static String blue = "§9";
   public static String green = "§a";
   public static String aqua = "§b";
   public static String red = "§c";
   public static String magenta = "§d";
   public static String yellow = "§e";
   public static String white = "§f";
   public static String underline = "§n";
   public static String bold = "§l";
   public static String italic = "§o";
   public static String strikethrough = "§m";
   public static String obfuscated = "§k";
   public static String reset = "§r";

   public static int rgbaToInt(int r, int g, int b, int a) {
      return (a & 0xFF) << 24 | (r & 0xFF) << 16 | (g & 0xFF) << 8 | b & 0xFF;
   }

   public static int rgbToInt(int r, int g, int b) {
      return (r & 0xFF) << 16 | (g & 0xFF) << 8 | b & 0xFF;
   }
}
