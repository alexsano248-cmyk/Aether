package net.aether.aether.module.settings;

import net.aether.aether.util.MathUtils;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class DoubleSetting extends Setting {
   public double value;
   private double min;
   private double max;
   private int roundingPlace;
   boolean sliding = false;

   public DoubleSetting(String name, double value, double min, double max, int roundingPlace) {
      this.name = name;
      this.value = value;
      this.min = min;
      this.max = max;
      this.roundingPlace = roundingPlace;
   }

   @Override
   public void render(class_332 drawContext, int x, int y, int mouseX, int mouseY, class_327 textRenderer) {
      super.render(drawContext, x, y, mouseX, mouseY, textRenderer);
      drawContext.method_27535(textRenderer, class_2561.method_43470(this.name), x + 2, y + 4, 16777215);
      double diff = Math.min(100.0, Math.max(0.0, (double)(mouseX - x) / 1.9));
      if (this.sliding) {
         if (diff == 0.0) {
            this.value = this.min;
         } else {
            double newValue = MathUtils.round(diff / 100.0 * (this.max - this.min) + this.min, this.roundingPlace);
            this.value = newValue;
         }
      }

      String valueString = MathUtils.round(this.value, this.roundingPlace) + "";
      drawContext.method_27535(textRenderer, class_2561.method_43470(valueString), x + 190 - textRenderer.method_1727(valueString), y + 4, 16777215);
      drawContext.method_25294(x + 2, y + 16, x + 190, y + 18, -10066330);
      int scaledValue = (int)(this.value / this.max * 190.0);
      drawContext.method_25294(x + 2, y + 16, x + 2 + scaledValue, y + 18, -11141121);
      drawContext.method_25294(x + 2 + (scaledValue - 1), y + 14, x + 2 + scaledValue + 1, y + 20, -1);
   }

   @Override
   public void mouseClicked(double mouseX, double mouseY, int button) {
      if (this.hovered((int)mouseX, (int)mouseY) && button == 0) {
         this.sliding = true;
      }
   }

   @Override
   public void mouseReleased(double mouseX, double mouseY, int button) {
      this.sliding = false;
   }
}
