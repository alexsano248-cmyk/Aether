package net.aether.aether.util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public class MathUtils {
   public static double round(double value, int places) {
      if (places < 0) {
         throw new IllegalArgumentException();
      } else {
         BigDecimal bd = new BigDecimal(Double.toString(value));
         bd = bd.setScale(places, RoundingMode.HALF_UP);
         return bd.doubleValue();
      }
   }

   public static int d2iSafe(Object value) {
      int out = 0;

      try {
         out = (int)Math.floor((Double)value);
      } catch (Exception var3) {
         out = (Integer)value;
      }

      return out;
   }

   public static double length2D(class_243 vec3d) {
      return (double)class_3532.method_15355((float)(vec3d.field_1352 * vec3d.field_1352 + vec3d.field_1350 * vec3d.field_1350));
   }

   public static void logPacket() {
   }

   public static float lerp(float start, float end, float factor) {
      return start + (end - start) * factor;
   }
}
