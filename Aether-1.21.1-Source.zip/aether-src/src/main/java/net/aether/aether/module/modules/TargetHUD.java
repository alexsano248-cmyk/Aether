package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.ModuleManager;
import net.aether.aether.module.settings.BooleanSetting;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_640;

public class TargetHUD extends Module {
   public final BooleanSetting showHead = new BooleanSetting("Show Head", true);
   public final BooleanSetting onlyWithKillAura = new BooleanSetting("Only with KillAura", true);

   public TargetHUD() {
      super("TargetHUD", "Shows a HUD for your KillAura target.", Category.RENDER, false);
      this.settings.add(this.showHead);
      this.settings.add(this.onlyWithKillAura);
   }

   public void render(class_332 ctx) {
      if (!this.enabled) return;
      class_310 mc = class_310.method_1551();
      if (mc.field_1724 == null) return;
      class_1309 t = KillAura.target;
      Module ka = ModuleManager.INSTANCE.getModuleByName("KillAura");
      if (this.onlyWithKillAura.value && (ka == null || !ka.enabled)) return;
      if (t == null) return;

      int sw = ctx.method_51421();
      int sh = ctx.method_51443();
      int x = sw / 2 + 20;
      int y = sh / 2 - 30;
      int boxW = 130; int boxH = 40;
      ctx.method_25294(x, y, x + boxW, y + boxH, 0xAA000000);
      ctx.method_49601(x, y, boxW, boxH, 0xFF55FFFF);

      class_327 fr = mc.field_1772;
      String name = t.method_5477().getString();
      ctx.method_51439(fr, class_2561.method_43470(name), x + 40, y + 5, 0xFFFFFFFF, true);

      float maxHp = t.method_6063();
      float hp = t.method_6032();
      String hpStr = String.format("%.1f / %.1f", hp, maxHp);
      int color = hp > maxHp * 0.66f ? 0xFF55FF55 : hp > maxHp * 0.33f ? 0xFFFFFF55 : 0xFFFF5555;
      ctx.method_51439(fr, class_2561.method_43470(hpStr), x + 40, y + 16, color, true);

      int barW = (int)((boxW - 50) * (hp / Math.max(1.0f, maxHp)));
      ctx.method_25294(x + 40, y + 28, x + 40 + (boxW - 50), y + 32, 0xFF333333);
      ctx.method_25294(x + 40, y + 28, x + 40 + barW, y + 32, color);

      // Skin head
      if (this.showHead.value && t instanceof class_1657 && mc.method_1562() != null) {
         class_640 entry = mc.method_1562().method_2871(((class_1657) t).method_5667());
         if (entry != null) {
            class_2960 tex = entry.method_52810().comp_1626();
            ctx.method_25290(class_1921::method_62277, tex, x + 4, y + 4, 8.0F, 8.0F, 32, 32, 64, 64);
            ctx.method_25290(class_1921::method_62277, tex, x + 4, y + 4, 40.0F, 8.0F, 32, 32, 64, 64);
         }
      }
   }
}
