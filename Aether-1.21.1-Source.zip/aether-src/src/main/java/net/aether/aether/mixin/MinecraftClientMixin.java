package net.aether.aether.mixin;

import net.aether.aether.Aether;
import net.aether.aether.module.Module;
import net.aether.aether.module.ModuleManager;
import net.aether.aether.module.modules.FPSSpoofer;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_310.class})
public class MinecraftClientMixin {
   @Shadow
   private int field_1735;

   @ModifyVariable(
      at = @At(
         value = "FIELD",
         target = "Lnet/minecraft/client/MinecraftClient;fpsCounter:I"
      ),
      method = {"render(Z)V"},
      index = 1,
      argsOnly = true
   )
   private boolean modifyFpsCounter(boolean value) {
      Module spoofer = ModuleManager.INSTANCE.getModuleByName("FPS Spoofer");
      if (spoofer != null && spoofer.enabled) {
         this.field_1735 = (int)((FPSSpoofer)spoofer).fakeFps.value;
         if (((FPSSpoofer)spoofer).fluctuate.value) {
            this.field_1735 = (int)(
               (double)this.field_1735
                  + ((double)((int)(Math.random() * ((FPSSpoofer)spoofer).fluctuateAmount.value * 2.0)) - ((FPSSpoofer)spoofer).fluctuateAmount.value)
            );
         }

         return true;
      } else {
         return value;
      }
   }

   @Inject(
      at = {@At("TAIL")},
      method = {"scheduleStop"}
   )
   public void onShutdown(CallbackInfo ci) {
      Aether.INSTANCE.saveConfig();
   }
}
