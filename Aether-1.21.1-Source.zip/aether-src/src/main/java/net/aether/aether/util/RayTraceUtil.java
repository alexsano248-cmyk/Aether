package net.aether.aether.util;

import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1675;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

public class RayTraceUtil {
   private static final class_310 mc = class_310.method_1551();

   public static class_1297 getLookedAtEntity(double distance) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_243 start = mc.field_1724.method_33571();
         class_243 direction = mc.field_1724.method_5828(1.0F);
         class_243 end = start.method_1019(direction.method_1021(distance));
         class_238 searchBox = new class_238(start, end).method_1014(1.0);
         class_3966 result = class_1675.method_18075(
            mc.field_1724, start, end, searchBox, entity -> !entity.method_7325() && entity.method_5805() && entity != mc.field_1724, distance
         );
         return result != null ? result.method_17782() : null;
      } else {
         return null;
      }
   }

   public static class_2680 getLookedAtBlock(double distance) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_243 start = mc.field_1724.method_5836(1.0F);
         class_243 end = start.method_1019(mc.field_1724.method_5828(1.0F).method_1021(distance));
         class_239 hitResult = mc.field_1687.method_17742(new class_3959(start, end, class_3960.field_17559, class_242.field_1348, mc.field_1724));
         if (hitResult.method_17783() == class_240.field_1332) {
            class_3965 blockHit = (class_3965)hitResult;
            return mc.field_1687.method_8320(blockHit.method_17777());
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   public static class_3965 getLookedAtBlockState(double distance) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_243 start = mc.field_1724.method_5836(1.0F);
         class_243 end = start.method_1019(mc.field_1724.method_5828(1.0F).method_1021(distance));
         return mc.field_1687.method_17742(new class_3959(start, end, class_3960.field_17559, class_242.field_1348, mc.field_1724));
      } else {
         return null;
      }
   }

   public static class_3965 getLookedAtBlockHitResult(double distance) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_243 start = mc.field_1724.method_5836(1.0F);
         class_243 end = start.method_1019(mc.field_1724.method_5828(1.0F).method_1021(distance));
         class_239 hitResult = mc.field_1687.method_17742(new class_3959(start, end, class_3960.field_17559, class_242.field_1348, mc.field_1724));
         return hitResult.method_17783() == class_240.field_1332 ? (class_3965)hitResult : null;
      } else {
         return null;
      }
   }

   public static String parseBlockName(String blockStateString) {
      if (blockStateString != null && blockStateString.contains("{") && blockStateString.contains("minecraft:")) {
         try {
            int startIndex = blockStateString.indexOf("minecraft:") + "minecraft:".length();
            int endIndex = blockStateString.indexOf("}", startIndex);
            if (startIndex > 0 && endIndex > startIndex) {
               return blockStateString.substring(startIndex, endIndex);
            }
         } catch (Exception var3) {
            var3.printStackTrace();
         }

         return "Unknown Block";
      } else {
         return "Unknown Block";
      }
   }

   public static String getLookedAtBlockName(double distance) {
      class_2680 block = getLookedAtBlock(distance);
      if (block != null) {
         String blockStateString = block.toString();
         return parseBlockName(blockStateString);
      } else {
         return "No Block";
      }
   }

   public static boolean isLookingAtCrystal(double distance) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_1297 entity = getLookedAtEntity(distance);
         return entity == null ? false : entity instanceof class_1511;
      } else {
         return false;
      }
   }
}
