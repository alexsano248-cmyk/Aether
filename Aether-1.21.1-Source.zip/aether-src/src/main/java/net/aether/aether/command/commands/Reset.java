package net.aether.aether.command.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.aether.aether.Aether;
import net.aether.aether.command.Command;
import net.minecraft.class_2172;

public class Reset extends Command {
   public Reset() {
      super("reset", "Resets all config options.");
   }

   @Override
   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.executes(context -> {
         Aether.CONFIG.loadDefaultConfig();
         return this.SINGLE_SUCCESS;
      });
   }
}
