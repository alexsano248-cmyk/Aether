package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.DropdownSetting;
import net.minecraft.class_5498;

public class Camera extends Module {
   public final DropdownSetting view = new DropdownSetting("View", "ThirdPerson", new String[]{"FirstPerson", "ThirdPerson", "ThirdFront"});

   public Camera() {
      super("Camera", "Forces a camera perspective.", Category.RENDER, false);
      this.settings.add(this.view);
   }

   @Override
   public void tick() {
      if (mc.field_1690 == null) return;
      switch (this.view.value) {
         case "FirstPerson": mc.field_1690.method_31043(class_5498.field_26664); break;
         case "ThirdPerson": mc.field_1690.method_31043(class_5498.field_26665); break;
         case "ThirdFront":  mc.field_1690.method_31043(class_5498.field_26666); break;
      }
   }
}
