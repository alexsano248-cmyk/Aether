package net.aether.aether;

import com.google.gson.Gson;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;
import net.aether.aether.command.CommandManager;
import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.ModuleManager;
import net.aether.aether.module.settings.BooleanSetting;
import net.aether.aether.module.settings.DoubleSetting;
import net.aether.aether.module.settings.IndexSetting;
import net.aether.aether.module.settings.KeycodeSetting;
import net.aether.aether.module.settings.Setting;
import net.aether.aether.module.settings.StringSetting;
import net.aether.aether.ui.clickgui.ClickGUIScreen;
import net.aether.aether.ui.hud.HUDModule;
import net.aether.aether.ui.hud.HUDModuleManager;
import net.minecraft.class_310;

public class Config {
   class_310 mc = class_310.method_1551();
   public File configDir = new File(this.mc.field_1697.getPath() + "/Aether Team");
   public File configFile = new File(this.configDir, "config.json");
   public Map<String, Object> config = new HashMap<>();
   protected static Gson gson = new Gson();

   public Config() {
      this.configDir.mkdirs();
   }

   public boolean doesConfigExist() {
      return !Files.exists(this.configFile.toPath());
   }

   public void loadDefaultConfig() {
      ModuleManager.INSTANCE = new ModuleManager();
      Map<String, Object> mi = new HashMap<>();

      for (Module m : ModuleManager.INSTANCE.modules) {
         Map<String, Object> mo = new HashMap<>();
         mo.put("enabled", m.enabled);
         Map<String, Object> ms = new HashMap<>();

         for (Setting s : m.settings) {
            if (s instanceof BooleanSetting) {
               ms.put(s.name, ((BooleanSetting)s).value);
            } else if (s instanceof DoubleSetting) {
               ms.put(s.name, ((DoubleSetting)s).value);
            } else if (s instanceof StringSetting) {
               ms.put(s.name, ((StringSetting)s).value);
            } else if (s instanceof KeycodeSetting) {
               ms.put(s.name, ((KeycodeSetting)s).value);
            } else if (s instanceof IndexSetting) {
               ms.put(s.name, ((IndexSetting)s).index);
            }
         }

         mo.put("settings", ms);
         mi.put(m.name, mo);
      }

      this.config.put("modules", mi);
      HUDModuleManager.INSTANCE = new HUDModuleManager();
      Map<String, Object> hi = new HashMap<>();

      for (HUDModule h : HUDModuleManager.INSTANCE.modules) {
         Map<String, Object> ho = new HashMap<>();
         ho.put("enabled", h.enabled);
         Map<String, Object> hs = new HashMap<>();

         for (Setting sx : h.settings) {
            if (sx instanceof BooleanSetting) {
               hs.put(sx.name, ((BooleanSetting)sx).value);
            } else if (sx instanceof DoubleSetting) {
               hs.put(sx.name, ((DoubleSetting)sx).value);
            } else if (sx instanceof StringSetting) {
               hs.put(sx.name, ((StringSetting)sx).value);
            } else if (sx instanceof KeycodeSetting) {
               hs.put(sx.name, ((KeycodeSetting)sx).value);
            } else if (sx instanceof IndexSetting) {
               hs.put(sx.name, ((IndexSetting)sx).index);
            }
         }

         ho.put("settings", hs);
         ho.put("x", h.x);
         ho.put("y", h.y);
         hi.put(h.name, ho);
      }

      this.config.put("hud", hi);
      int xOffset = 4;
      int yOffset = 4;
      Map<String, Object> pi = new HashMap<>();

      for (Category category : Category.values()) {
         Map<String, Object> po = new HashMap<>();
         if (xOffset > 400) {
            xOffset = 4;
            yOffset = 128;
         }

         po.put("x", xOffset);
         po.put("y", yOffset);
         po.put("collapsed", false);
         pi.put(category.name, po);
         xOffset += 100;
      }

      this.config.put("panes", pi);
      ClickGUIScreen.INSTANCE = new ClickGUIScreen();
      Map<String, Object> general = new HashMap<>();
      general.put("prefix", new CommandManager().getPrefix());
      this.config.put("general", general);
   }

   public void load() throws IOException {
      try {
         String configText = new String(Files.readAllBytes(this.configFile.toPath()));
         this.config = (Map<String, Object>)gson.fromJson(configText, Map.class);
      } catch (Exception var2) {
         throw new IOException("Failed to load config file.");
      }
   }

   public void save() {
      try {
         if (!this.doesConfigExist()) {
            this.configFile.createNewFile();
         }
      } catch (Exception var4) {
         var4.printStackTrace();
      }

      try {
         String configText = gson.toJson(this.config);
         FileWriter writer = new FileWriter(this.configFile);
         writer.write(configText);
         writer.close();
      } catch (Exception var3) {
         var3.printStackTrace();
      }
   }
}
