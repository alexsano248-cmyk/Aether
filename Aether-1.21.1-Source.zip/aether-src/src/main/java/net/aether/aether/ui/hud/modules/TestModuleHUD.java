package net.aether.aether.ui.hud.modules;

import net.aether.aether.module.settings.DoubleSetting;
import net.aether.aether.module.settings.StringSetting;
import net.aether.aether.ui.hud.HUDModule;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class TestModuleHUD extends HUDModule {
   public StringSetting text = new StringSetting("Text", "hii :3");
   public DoubleSetting number = new DoubleSetting("test", 1.0, 0.0, 10.0, 0);

   public TestModuleHUD(int x, int y) {
      super("Test HUD Module", x, y);
      this.width = 96;
      this.height = 8;
      this.settings.add(this.text);
      this.settings.add(this.number);
   }

   @Override
   public void render(class_332 drawContext, int mouseX, int mouseY, class_327 textRenderer, boolean editMode, boolean enabled) {
      super.render(drawContext, mouseX, mouseY, textRenderer, editMode, enabled);
      drawContext.method_51433(textRenderer, this.text.value, this.x, this.y, 16777215, false);
   }
}
