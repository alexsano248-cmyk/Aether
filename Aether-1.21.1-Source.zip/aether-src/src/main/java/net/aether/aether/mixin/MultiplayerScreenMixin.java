package net.aether.aether.mixin;

import net.aether.aether.ui.SessionManagerScreen;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_500;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_500.class})
public class MultiplayerScreenMixin extends class_437 {
   protected MultiplayerScreenMixin(class_2561 title) {
      super(title);
   }

   @Inject(
      method = {"init"},
      at = {@At("RETURN")}
   )
   public void onInit(CallbackInfo ci) {
      this.method_37063(
         (class_4185)this.method_37063(
            class_4185.method_46430(class_2561.method_30163("Session Manager"), button -> this.field_22787.method_1507(new SessionManagerScreen()))
               .method_46434(10, 10, 120, 20)
               .method_46431()
         )
      );
   }
}
