package net.aether.aether.ui.clickgui;

import net.aether.aether.module.Module;
import net.aether.aether.module.ModuleManager;
import net.aether.aether.util.MathUtils;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class ModuleButton {
   public Module module;
   public int x;
   public int y;
   public int width;
   public int height = 16;
   private float hoverProgress = 0.0F;
   private static final float HOVER_SPEED = 0.7F;
   private static final int TOOLTIP_PADDING = 4;
   private static final int TOOLTIP_MAX_WIDTH = 400;

   public ModuleButton(Module module) {
      this.module = module;
      this.width = 88;
   }

   public void render(class_332 drawContext, int mouseX, int mouseY, int x, int y, class_327 textRenderer) {
      this.x = x;
      this.y = y;
      if (ModuleManager.isBlatantMode() || !this.module.blatant) {
         float targetHover = this.hovered(mouseX, mouseY) ? 1.0F : 0.0F;
         if (this.hoverProgress != targetHover) {
            this.hoverProgress = MathUtils.lerp(this.hoverProgress, targetHover, 0.7F);
         }

         int baseColor = -14013910;
         int hoverColor = -12961222;
         int enabledColor = -11751600;
         int disabledColor = -1754827;
         int backgroundColor = this.interpolateColor(baseColor, hoverColor, this.hoverProgress);
         this.drawRoundedButton(drawContext, x, y, this.width, this.height, backgroundColor);
         int statusColor = this.module.enabled ? enabledColor : disabledColor;
         drawContext.method_25294(x + 2, y + 2, x + 4, y + this.height - 2, statusColor);
         int textColor = this.module.enabled ? -1 : -5592406;
         drawContext.method_51433(textRenderer, this.module.name, x + 8, y + 4, textColor, false);
      }
   }

   public void renderTooltip(class_332 drawContext, int mouseX, int mouseY, class_327 textRenderer) {
      if (ModuleManager.isBlatantMode() || !this.module.blatant) {
         if (this.hovered(mouseX, mouseY)) {
            String description = this.module.description;
            int tooltipWidth = Math.min(textRenderer.method_1727(description), 400);
            int tooltipHeight = 9 + 8;
            drawContext.method_25294(this.x + this.width + 5, this.y, this.x + this.width + 5 + tooltipWidth + 8, this.y + tooltipHeight, -16777216);
            int statusColor = this.module.enabled ? -11751600 : -1754827;
            drawContext.method_25294(this.x + this.width + 5, this.y, this.x + this.width + 6, this.y + tooltipHeight, statusColor);
            drawContext.method_51433(textRenderer, description, this.x + this.width + 5 + 4, this.y + 4, -1, false);
         }
      }
   }

   private void drawRoundedButton(class_332 drawContext, int x, int y, int width, int height, int color) {
      int radius = 3;
      drawContext.method_25294(x + radius, y, x + width - radius, y + height, color);
      drawContext.method_25294(x, y + radius, x + radius, y + height - radius, color);
      drawContext.method_25294(x + width - radius, y + radius, x + width, y + height - radius, color);
      this.drawFilledCircle(drawContext, x + radius, y + radius, radius, color);
      this.drawFilledCircle(drawContext, x + width - radius - 1, y + radius, radius, color);
      this.drawFilledCircle(drawContext, x + radius, y + height - radius - 1, radius, color);
      this.drawFilledCircle(drawContext, x + width - radius - 1, y + height - radius - 1, radius, color);
   }

   private void drawFilledCircle(class_332 drawContext, int centerX, int centerY, int radius, int color) {
      int squareRadius = radius * radius;

      for (int x = -radius; x <= radius; x++) {
         for (int y = -radius; y <= radius; y++) {
            if (x * x + y * y <= squareRadius) {
               drawContext.method_25294(centerX + x, centerY + y, centerX + x + 1, centerY + y + 1, color);
            }
         }
      }
   }

   private int interpolateColor(int color1, int color2, float factor) {
      int r1 = color1 >> 16 & 0xFF;
      int g1 = color1 >> 8 & 0xFF;
      int b1 = color1 & 0xFF;
      int r2 = color2 >> 16 & 0xFF;
      int g2 = color2 >> 8 & 0xFF;
      int b2 = color2 & 0xFF;
      int r = (int)((float)r1 + (float)(r2 - r1) * factor);
      int g = (int)((float)g1 + (float)(g2 - g1) * factor);
      int b = (int)((float)b1 + (float)(b2 - b1) * factor);
      return 0xFF000000 | r << 16 | g << 8 | b;
   }

   public boolean hovered(int mouseX, int mouseY) {
      return mouseX >= this.x && mouseX <= this.x + this.width && mouseY >= this.y && mouseY <= this.y + this.height;
   }

   public boolean mouseClicked(int mouseX, int mouseY, int button) {
      if (!ModuleManager.isBlatantMode() && this.module.blatant) {
         return false;
      } else if (this.hovered(mouseX, mouseY)) {
         if (button == 0) {
            this.module.toggle();
         } else if (button == 1) {
            class_310.method_1551().method_1507(new SettingsScreen(this.module));
         }

         return true;
      } else {
         return false;
      }
   }
}
