package net.aether.aether.module.settings;

import net.aether.aether.util.KeycodeUtils;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class KeycodeSetting extends Setting {
   public int value;
   public boolean isWaiting = false;

   public KeycodeSetting(String name, int value) {
      this.name = name;
      this.value = value;
   }

   @Override
   public void mouseClicked(double mouseX, double mouseY, int button) {
      if (this.isWaiting) {
         this.isWaiting = false;
      } else {
         if (this.hovered((int)mouseX, (int)mouseY) && button == 0) {
            this.isWaiting = true;
         }
      }
   }

   @Override
   public void render(class_332 drawContext, int x, int y, int mouseX, int mouseY, class_327 textRenderer) {
      super.render(drawContext, x, y, mouseX, mouseY, textRenderer);
      drawContext.method_27535(textRenderer, class_2561.method_43470(this.name), x + 2, y + 8, 16777215);
      if (this.isWaiting) {
         String waiting = "Press any key.";
         int twwidth = textRenderer.method_1727(waiting);
         drawContext.method_25303(textRenderer, waiting, x + 190 - twwidth, y + 8, 16777215);
      } else {
         String key = KeycodeUtils.keyTable[this.value];
         if (this.value == 256) {
            key = "";
         }

         int twidth = textRenderer.method_1727(key);
         drawContext.method_25303(textRenderer, key, x + 190 - twidth, y + 8, 16777215);
      }
   }

   @Override
   public void keyPressed(int keyCode, int scanCode, int modifiers) {
      if (this.isWaiting) {
         if (keyCode == 256) {
            this.value = 0;
            this.isWaiting = false;
            return;
         }

         this.value = keyCode;
         this.isWaiting = false;
      }
   }
}
