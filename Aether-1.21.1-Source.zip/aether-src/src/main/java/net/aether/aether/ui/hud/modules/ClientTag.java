package net.aether.aether.ui.hud.modules;

import net.aether.aether.Aether;
import net.aether.aether.ui.hud.HUDModule;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class ClientTag extends HUDModule {
   public ClientTag(int x, int y) {
      super("Client Tag", x, y);
      this.width = 128;
      this.height = 8;
      this.enabled = true;
   }

   @Override
   public void render(class_332 drawContext, int mouseX, int mouseY, class_327 textRenderer, boolean editMode, boolean enabled) {
      super.render(drawContext, mouseX, mouseY, textRenderer, editMode, enabled);
      drawContext.method_25303(mc.field_1772, Aether.clientTag + " " + Aether.versionTag, this.x, this.y, 16777215);
   }
}
