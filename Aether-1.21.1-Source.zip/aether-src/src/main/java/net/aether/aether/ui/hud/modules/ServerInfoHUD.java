package net.aether.aether.ui.hud.modules;

import net.aether.aether.ui.hud.HUDModule;
import net.aether.aether.util.ColorUtils;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_634;
import net.minecraft.class_642;
import net.minecraft.class_746;

public class ServerInfoHUD extends HUDModule {
   public ServerInfoHUD(int x, int y) {
      super("Server Info", x, y);
      this.width = 128;
      this.height = 32;
      this.enabled = true;
   }

   @Override
   public void render(class_332 drawContext, int mouseX, int mouseY, class_327 textRenderer, boolean editMode, boolean enabled) {
      super.render(drawContext, mouseX, mouseY, textRenderer, editMode, enabled);
      class_746 player = class_310.method_1551().field_1724;
      if (player != null) {
         class_642 serverData = class_310.method_1551().method_1558();
         String serverIP = serverData != null ? serverData.field_3761 : "Singleplayer";
         int yOffset = 0;
         int lineHeight = 9 + 1;
         drawContext.method_25303(textRenderer, ColorUtils.aqua + "Server: " + ColorUtils.white + serverIP, this.x, this.y + yOffset, 16777215);
         yOffset += lineHeight;
         if (serverData != null) {
            class_634 networkHandler = class_310.method_1551().method_1562();
            if (networkHandler != null) {
               int online = networkHandler.method_2880().size();
               int max = class_310.method_1551().method_1558().field_41861.comp_1279();
               drawContext.method_25303(
                  textRenderer, ColorUtils.aqua + "Players: " + ColorUtils.white + online + " / " + max, this.x, this.y + yOffset, 16777215
               );
               yOffset += lineHeight;
            }
         }

         if (serverData != null) {
            String versionString = serverData.field_3760.toString();
            String cleaned = versionString != null ? versionString : "";
            int start = cleaned.indexOf(123);
            int end = cleaned.indexOf(125, start + 1);
            if (start != -1 && end != -1) {
               cleaned = cleaned.substring(start + 1, end);
            }

            String displayVersion = cleaned.split("\\s+\\(")[0];
            drawContext.method_25303(textRenderer, ColorUtils.aqua + "Software: " + ColorUtils.white + displayVersion, this.x, this.y + yOffset, 16777215);
            yOffset += lineHeight;
         }
      }
   }
}
