package net.aether.aether.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.ModuleManager;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;

public class ModulesListOverlay {
   public static ModulesListOverlay INSTANCE = new ModulesListOverlay();
   private class_310 mc = class_310.method_1551();
   private ArrayList<Module> enabledModules = ModuleManager.INSTANCE.getEnabledModules();
   private Map<Module, Float> moduleAnimations = new HashMap<>();
   private static final float ANIMATION_SPEED = 0.2F;
   private static final int PADDING = 1;
   private static final int MODULE_HEIGHT = 14;
   private static final int ACCENT_WIDTH = 2;
   private static final int TOOLTIP_PADDING = 4;
   private static final int TOOLTIP_MAX_WIDTH = 400;

   public void render(class_332 drawContext, int scaledWidth, int scaledHeight) {
      if (!this.mc.method_53526().method_53536()) {
         int yOffset = 1;
         Module hoveredModule = null;

         for (Module m : this.enabledModules) {
            if (m.showInModulesList.value) {
               float targetAlpha = m.enabled ? 1.0F : 0.0F;
               float currentAlpha = this.moduleAnimations.getOrDefault(m, 0.0F);
               float newAlpha = class_3532.method_16439(0.2F, currentAlpha, targetAlpha);
               this.moduleAnimations.put(m, newAlpha);
               if (!(newAlpha < 0.01F)) {
                  int nameWidth = this.mc.field_1772.method_1727(m.name);
                  int totalWidth = nameWidth + 2;
                  drawContext.method_25294(scaledWidth - totalWidth - 2, yOffset, scaledWidth, yOffset + 14, 1998725666);
                  drawContext.method_25294(scaledWidth - 2, yOffset, scaledWidth, yOffset + 14, this.getCategoryColor(m.category));
                  drawContext.method_51433(this.mc.field_1772, m.name, scaledWidth - totalWidth, yOffset + 3, -1, false);
                  double mouseX = this.mc.field_1729.method_1603() * (double)scaledWidth / (double)this.mc.method_22683().method_4480();
                  double mouseY = this.mc.field_1729.method_1604() * (double)scaledHeight / (double)this.mc.method_22683().method_4507();
                  if (mouseX >= (double)(scaledWidth - totalWidth - 2)
                     && mouseX <= (double)scaledWidth
                     && mouseY >= (double)yOffset
                     && mouseY <= (double)(yOffset + 14)) {
                     ;
                  }

                  yOffset += 14;
               }
            }
         }
      }
   }

   private int getCategoryColor(Category category) {
      return switch (category) {
         case COMBAT -> -43691;
         case MOVEMENT -> -11141291;
         case RENDER -> -11184641;
         case PLAYER -> -171;
         case WORLD -> -43521;
         default -> -11141121;
      };
   }

   public void update() {
      this.enabledModules = ModuleManager.INSTANCE.getEnabledModules();
   }
}
