package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.BooleanSetting;
import net.aether.aether.module.settings.DoubleSetting;
import net.aether.aether.module.settings.DropdownSetting;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;

public class KillAura extends Module {
   public static class_1309 target = null;

   public final DoubleSetting range = new DoubleSetting("Range", 4.2, 1.0, 8.0, 1);
   public final DoubleSetting cps = new DoubleSetting("CPS", 12.0, 1.0, 20.0, 0);
   public final DropdownSetting mode = new DropdownSetting("Mode", "Single", new String[]{"Single", "Switch", "Multi"});
   public final BooleanSetting players = new BooleanSetting("Players", true);
   public final BooleanSetting mobs = new BooleanSetting("Mobs", false);
   public final BooleanSetting invisibles = new BooleanSetting("Hit Invisibles", false);

   private long lastAttack = 0L;

   public KillAura() {
      super("KillAura", "Automatically attacks nearby entities.", Category.COMBAT, true);
      this.settings.add(this.range);
      this.settings.add(this.cps);
      this.settings.add(this.mode);
      this.settings.add(this.players);
      this.settings.add(this.mobs);
      this.settings.add(this.invisibles);
   }

   @Override
   public void tick() {
      if (mc.field_1724 == null || mc.field_1687 == null) { target = null; return; }
      long now = System.currentTimeMillis();
      long delay = (long)(1000.0 / Math.max(1.0, this.cps.value));
      if (now - this.lastAttack < delay) return;

      class_1309 best = null;
      double bestDist = this.range.value;
      for (class_1297 e : mc.field_1687.method_18112()) {
         if (!(e instanceof class_1309)) continue;
         if (e == mc.field_1724) continue;
         class_1309 le = (class_1309) e;
         if (le.method_29504()) continue;
         if (!this.invisibles.value && le.method_5767()) continue;
         if (e instanceof class_1657) { if (!this.players.value) continue; }
         else if (!this.mobs.value) continue;
         double d = mc.field_1724.method_5739(e);
         if (d <= bestDist) { bestDist = d; best = le; }
      }
      target = best;
      if (best == null) return;

      mc.field_1761.method_2918(mc.field_1724, best);
      mc.field_1724.method_6104(net.minecraft.class_1268.field_5808);
      this.lastAttack = now;

      if (this.mode.value.equalsIgnoreCase("Switch")) {
         // attack one, allow target swap next tick naturally
      }
   }

   @Override
   public void onDisable() {
      super.onDisable();
      target = null;
   }
}
