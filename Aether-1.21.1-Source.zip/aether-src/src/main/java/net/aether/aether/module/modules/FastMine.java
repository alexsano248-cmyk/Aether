package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.BooleanSetting;
import net.aether.aether.module.settings.DoubleSetting;
import net.aether.aether.module.settings.DropdownSetting;
import net.aether.aether.util.RayTraceUtil;

public class FastMine extends Module {
   public final DropdownSetting mode = new DropdownSetting("Mode", "Instant", new String[]{"Instant", "Fast", "Custom"});
   public final DoubleSetting speed = new DoubleSetting("Speed", 1.0, 0.1, 5.0, 1);
   private final BooleanSetting onlyOres = new BooleanSetting("Only Ores", false);

   public FastMine() {
      super("Fast Mine", "Lets you mine faster", Category.WORLD, true);
      this.settings.add(this.mode);
      this.settings.add(this.speed);
      this.settings.add(this.onlyOres);
   }

   @Override
   public void onDisable() {
      super.onDisable();
   }

   @Override
   public void onEnable() {
      super.onEnable();
   }

   public boolean shouldFastMine() {
      if (!this.enabled) {
         return false;
      } else {
         String blockId = String.valueOf(RayTraceUtil.getLookedAtBlock(3.0));
         return !this.onlyOres.value
            ? true
            : blockId.contains("ore")
               || blockId.contains("diamond")
               || blockId.contains("emerald")
               || blockId.contains("gold")
               || blockId.contains("iron")
               || blockId.contains("coal")
               || blockId.contains("lapis")
               || blockId.contains("redstone")
               || blockId.contains("quartz");
      }
   }
}
