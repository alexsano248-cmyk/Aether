package net.aether.aether.ui.hud.editor;

import net.aether.aether.ui.hud.HUDModule;
import net.aether.aether.ui.hud.HUDModuleManager;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class HUDEditorScreen extends class_437 {
   public static HUDEditorScreen INSTANCE = new HUDEditorScreen();
   HUDModuleList moduleList = new HUDModuleList(256, 2, false);

   public HUDEditorScreen() {
      super(class_2561.method_43470("HUD Editor"));
   }

   public void method_25394(class_332 drawContext, int mouseX, int mouseY, float delta) {
      this.method_25420(drawContext, mouseX, mouseY, delta);

      for (HUDModule h : HUDModuleManager.INSTANCE.modules) {
         h.render(drawContext, mouseX, mouseY, this.field_22793, true, h.enabled);
      }

      this.moduleList.render(drawContext, mouseX, mouseY, delta, this.field_22793);
   }

   public boolean method_25402(double mouseX, double mouseY, int button) {
      for (HUDModule h : HUDModuleManager.INSTANCE.modules) {
         h.mouseClicked((int)mouseX, (int)mouseY, button);
      }

      this.moduleList.mouseClicked((int)mouseX, (int)mouseY, button);
      return super.method_25402(mouseX, mouseY, button);
   }

   public boolean method_25406(double mouseX, double mouseY, int button) {
      for (HUDModule h : HUDModuleManager.INSTANCE.modules) {
         h.mouseReleased((int)mouseX, (int)mouseY, button);
      }

      this.moduleList.mouseReleased((int)mouseX, (int)mouseY, button);
      return super.method_25406(mouseX, mouseY, button);
   }

   public boolean method_25421() {
      return false;
   }
}
