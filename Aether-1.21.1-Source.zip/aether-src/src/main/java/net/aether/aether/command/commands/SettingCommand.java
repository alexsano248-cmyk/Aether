package net.aether.aether.command.commands;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.aether.aether.command.Command;
import net.aether.aether.module.Module;
import net.aether.aether.module.ModuleManager;
import net.aether.aether.module.settings.BooleanSetting;
import net.aether.aether.module.settings.DoubleSetting;
import net.aether.aether.module.settings.KeycodeSetting;
import net.aether.aether.module.settings.Setting;
import net.aether.aether.module.settings.StringSetting;
import net.aether.aether.util.ChatUtils;
import net.aether.aether.util.ColorUtils;
import net.minecraft.class_2172;

public class SettingCommand extends Command {
   public SettingCommand() {
      super("setting", "Change a setting of a module.");
   }

   @Override
   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(
         argument("module", StringArgumentType.string())
            .then(argument("setting", StringArgumentType.string()).then(argument("value", StringArgumentType.string()).executes(context -> {
               String m = (String)context.getArgument("module", String.class);
               String s = (String)context.getArgument("setting", String.class);
               String v = (String)context.getArgument("value", String.class);
               Module module = ModuleManager.INSTANCE.getModuleByName(m);
               if (module == null) {
                  ChatUtils.sendMsg(ColorUtils.red + "Invalid Module Name");
                  return 0;
               } else {
                  Setting setting = module.getSettingByName(s);
                  if (setting == null) {
                     ChatUtils.sendMsg(ColorUtils.red + "Invalid Setting Name");
                     return 0;
                  } else {
                     if (setting instanceof BooleanSetting) {
                        try {
                           ((BooleanSetting)setting).value = Boolean.parseBoolean(v);
                        } catch (Exception var11) {
                           ChatUtils.sendMsg(ColorUtils.red + "Invalid Value, expected boolean");
                           return 0;
                        }
                     } else if (setting instanceof DoubleSetting) {
                        try {
                           ((DoubleSetting)setting).value = Double.parseDouble(v);
                        } catch (Exception var10) {
                           ChatUtils.sendMsg(ColorUtils.red + "Invalid Value, expected Double");
                           return 0;
                        }
                     } else if (setting instanceof StringSetting) {
                        try {
                           ((StringSetting)setting).value = v;
                        } catch (Exception var9) {
                           ChatUtils.sendMsg(ColorUtils.red + "Invalid Value, expected String");
                           return 0;
                        }
                     } else if (setting instanceof KeycodeSetting) {
                        try {
                           int kv = Integer.parseInt(v);
                           if (kv > 348) {
                              ChatUtils.sendMsg(ColorUtils.red + "Keycode Value is too high, maximum is 348 (Menu)");
                              return 0;
                           }

                           if (kv < 0) {
                              ChatUtils.sendMsg(ColorUtils.red + "Keycode Value must be positive");
                              return 0;
                           }

                           ((KeycodeSetting)setting).value = kv;
                        } catch (Exception var8) {
                           ChatUtils.sendMsg(ColorUtils.red + "Invalid Value, expected Keycode (integer)");
                           return 0;
                        }
                     }

                     return this.SINGLE_SUCCESS;
                  }
               }
            })))
      );
   }
}
