package net.aether.aether.mixin;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.aether.aether.command.CommandManager;
import net.aether.aether.util.ChatUtils;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_2797;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_2535.class})
public class ClientConnectionMixin {
   @Inject(
      method = {"send(Lnet/minecraft/network/packet/Packet;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void send(class_2596<?> packet, CallbackInfo ci) {
      if (packet instanceof class_2797 && ((class_2797)packet).comp_945().startsWith(CommandManager.get().getPrefix())) {
         try {
            CommandManager.get().dispatch(((class_2797)packet).comp_945().substring(CommandManager.get().getPrefix().length()));
         } catch (CommandSyntaxException var4) {
            var4.printStackTrace();
            ChatUtils.sendMsg(var4.getMessage());
         }

         ci.cancel();
      }
   }
}
