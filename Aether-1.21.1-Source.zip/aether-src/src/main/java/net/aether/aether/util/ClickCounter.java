package net.aether.aether.util;

import java.util.ArrayList;
import java.util.List;

public class ClickCounter {
   public static final ClickCounter INSTANCE = new ClickCounter();
   private final List<Long> leftClicks = new ArrayList<>();
   private final List<Long> rightClicks = new ArrayList<>();

   public synchronized void registerLeftClick() {
      this.leftClicks.add(System.currentTimeMillis());
   }

   public synchronized void registerRightClick() {
      this.rightClicks.add(System.currentTimeMillis());
   }

   public int getLeftCPS() {
      return this.calculateCPS(this.leftClicks);
   }

   public int getRightCPS() {
      return this.calculateCPS(this.rightClicks);
   }

   private int calculateCPS(List<Long> clicks) {
      long currentTime = System.currentTimeMillis();
      clicks.removeIf(time -> currentTime - time > 1000L);
      return clicks.size();
   }
}
