package net.aether.aether.ui.hud.modules;

import net.aether.aether.ui.hud.HUDModule;
import net.aether.aether.util.ColorUtils;
import net.aether.aether.util.TickRateUtil;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class TPS extends HUDModule {
   public TPS(int x, int y) {
      super("TPS", x, y);
      this.width = 48;
      this.height = 8;
      this.enabled = true;
   }

   @Override
   public void render(class_332 drawContext, int mouseX, int mouseY, class_327 textRenderer, boolean editMode, boolean enabled) {
      super.render(drawContext, mouseX, mouseY, textRenderer, editMode, enabled);
      float tps = TickRateUtil.INSTANCE.getTickRate();
      drawContext.method_25303(textRenderer, ColorUtils.aqua + "TPS: " + ColorUtils.white + String.format("%.1f", tps), this.x, this.y, 16777215);
   }
}
