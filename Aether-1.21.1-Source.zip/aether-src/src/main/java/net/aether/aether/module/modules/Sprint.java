package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.DropdownSetting;
import net.aether.aether.module.settings.DoubleSetting;
import net.minecraft.class_5134;

public class Sprint extends Module {
   public final DropdownSetting mode = new DropdownSetting("Mode", "Normal", new String[]{"Normal", "Omni"});
   public final DoubleSetting boost = new DoubleSetting("Omni Boost", 0.5, 0.0, 1.0, 1);
   private double oldSpeed = -1.0;

   public Sprint() {
      super("Sprint", "Allows you to move faster. Omni: extra speed in all directions.", Category.MOVEMENT, false);
      this.settings.add(this.mode);
      this.settings.add(this.boost);
   }

   @Override
   public void onEnable() {
      super.onEnable();
      if (mc.field_1724 != null) {
         this.oldSpeed = mc.field_1724.method_5996(class_5134.field_23719).method_6201();
      }
   }

   @Override
   public void tick() {
      if (mc.field_1724 == null) return;
      boolean omni = this.mode.value.equalsIgnoreCase("Omni");
      if (omni) {
         mc.field_1724.method_5728(true);
         if (this.oldSpeed > 0) {
            mc.field_1724.method_5996(class_5134.field_23719).method_6192(this.oldSpeed * (1.0 + this.boost.value));
         }
      } else if (mc.field_1724.field_3913.field_3905 == 0.0F && mc.field_1724.field_3913.field_3907 == 0.0F) {
         mc.field_1724.method_5728(false);
      } else {
         mc.field_1724.method_5728(true);
      }
   }

   @Override
   public void onDisable() {
      super.onDisable();
      if (mc.field_1724 != null) {
         mc.field_1724.method_5728(false);
         if (this.oldSpeed > 0) {
            mc.field_1724.method_5996(class_5134.field_23719).method_6192(this.oldSpeed);
         }
      }
   }
}
