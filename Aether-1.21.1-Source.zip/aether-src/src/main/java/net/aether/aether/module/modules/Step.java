package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.DoubleSetting;
import net.minecraft.class_5134;

public class Step extends Module {
   DoubleSetting stepHeight = new DoubleSetting("Height", 1.0, 1.0, 10.0, 0);
   double old = 0.6;

   public Step() {
      super("Step", "Allows you to step up full blocks.", Category.MOVEMENT, true);
      this.settings.add(this.stepHeight);
   }

   @Override
   public void onEnable() {
      super.onEnable();
      this.old = mc.field_1724.method_5996(class_5134.field_47761).method_6201();
   }

   @Override
   public void tick() {
      mc.field_1724.method_5996(class_5134.field_47761).method_6192(this.stepHeight.value);
   }

   @Override
   public void onDisable() {
      super.onDisable();
      mc.field_1724.method_5996(class_5134.field_47761).method_6192(this.old);
   }
}
