package net.aether.aether.event.events;

import net.aether.aether.event.Event;
import net.minecraft.class_2596;

public class PacketEvent extends Event {
   public final class_2596<?> packet;

   public PacketEvent(class_2596<?> packet) {
      this.packet = packet;
   }

   public class_2596<?> getPacket() {
      return this.packet;
   }

   public static class Receive extends PacketEvent {
      public Receive(class_2596<?> packet) {
         super(packet);
      }
   }
}
