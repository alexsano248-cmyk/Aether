package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.BooleanSetting;
import net.aether.aether.module.settings.DoubleSetting;
import net.aether.aether.util.ClickCounter;
import net.aether.aether.util.InteractionUtil;
import net.aether.aether.util.RayTraceUtil;
import net.minecraft.class_1268;
import net.minecraft.class_2246;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

public class AutoHitCrystal extends Module {
   private int step = 0;
   private int tickCounter = 0;
   private final DoubleSetting DELAY_TICKS = new DoubleSetting("Delay", 1.0, 0.1, 10.0, 0);
   private final BooleanSetting simulate = new BooleanSetting("Simulate Clicks", true);
   private final BooleanSetting rightclicksword = new BooleanSetting("Right click sword", false);
   private static final double REACH_DISTANCE = 4.5;

   public AutoHitCrystal() {
      super("AutoHitCrystal", "Automatically places obsidian and a crystal", Category.COMBAT, true);
      this.settings.add(this.DELAY_TICKS);
      this.settings.add(this.simulate);
      this.settings.add(this.rightclicksword);
   }

   private void toggle2() {
      if (!this.rightclicksword.value) {
         this.toggle();
      } else {
         this.step = 0;
      }
   }

   @Override
   public void onEnable() {
      super.onEnable();
      this.tickCounter = 0;
      if (!this.rightclicksword.value) {
         this.step = 1;
      }
   }

   @Override
   public void tick() {
      if (this.enabled) {
         if (mc.field_1724 != null && mc.field_1687 != null) {
            if (InteractionUtil.inputActive("right") && this.rightclicksword.value && (InteractionUtil.holding("sword") || InteractionUtil.holding("crystal"))) {
               this.step = 1;
            }

            if (this.step == 1) {
               class_2680 lookingAt = RayTraceUtil.getLookedAtBlock(4.5);
               if (lookingAt == null) {
                  this.toggle2();
                  return;
               }

               if (lookingAt.method_26204() != class_2246.field_10540 && lookingAt.method_26204() != class_2246.field_9987) {
                  InteractionUtil.switchToBlock("obsidian");
                  this.rightClickBlock();
                  this.step = 2;
                  this.tickCounter = 0;
               } else {
                  InteractionUtil.switchToBlock("end_crystal");
                  this.rightClickBlock();
               }
            } else if (this.step == 2) {
               if (this.DELAY_TICKS.value <= 0.0) {
                  InteractionUtil.switchToBlock("end_crystal");
                  this.rightClickBlock();
                  this.toggle2();
               } else {
                  this.tickCounter++;
                  if ((double)this.tickCounter >= this.DELAY_TICKS.value) {
                     InteractionUtil.switchToBlock("end_crystal");
                     this.rightClickBlock();
                     this.toggle2();
                  }
               }
            }
         }
      }
   }

   private void rightClickBlock() {
      if (mc.field_1724 != null) {
         if (mc.field_1765 instanceof class_3965 blockHit) {
            if (this.simulate.value) {
               mc.field_1690.field_1904.method_23481(true);
               ClickCounter.INSTANCE.registerRightClick();
               mc.field_1690.field_1904.method_23481(false);
            }

            mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, blockHit);
         }
      }
   }
}
