package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.DoubleSetting;
import net.aether.aether.util.Timer;

public class AutoAFK extends Module {
   public DoubleSetting delay = new DoubleSetting("Delay (Seconds)", 1.0, 0.1, 10.0, 1);
   private Timer timer = new Timer();

   public AutoAFK() {
      super("Auto AFK", "Automatically jumps to prevent AFK checks.", Category.MOVEMENT, false);
      this.settings.add(this.delay);
   }

   @Override
   public void tick() {
      if (this.timer.hasTimeElapsed((long)this.delay.value * 1000L, true) && mc.field_1724.method_24828() && !mc.field_1724.method_5765()) {
         mc.field_1724.method_6043();
      }
   }
}
