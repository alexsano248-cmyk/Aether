package net.aether.aether.command.commands;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.aether.aether.command.Command;
import net.aether.aether.command.CommandManager;
import net.aether.aether.util.ChatUtils;
import net.aether.aether.util.ColorUtils;
import net.minecraft.class_2172;

public class Prefix extends Command {
   public Prefix() {
      super("prefix", "Sets the prefix of the commands.");
   }

   @Override
   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(argument("key", StringArgumentType.greedyString()).executes(context -> {
         String key = StringArgumentType.getString(context, "key");
         CommandManager.get().setPrefix(key);
         ChatUtils.sendMsg(ColorUtils.green + "Prefix set to " + key);
         return this.SINGLE_SUCCESS;
      }));
   }
}
