package net.aether.aether.module.settings;

import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class IndexSetting extends Setting {
   public int index;
   public String[] elements;

   public IndexSetting(String name, int index, String... elements) {
      this.name = name;
      this.index = index;
      this.elements = elements;
   }

   @Override
   public void render(class_332 drawContext, int x, int y, int mouseX, int mouseY, class_327 textRenderer) {
      super.render(drawContext, x, y, mouseX, mouseY, textRenderer);
      drawContext.method_27535(textRenderer, class_2561.method_43470(this.name), x + 2, y + 8, 16777215);
      drawContext.method_25294(x + 96, y + 5, x + 190, y + 19, -1);
      drawContext.method_25294(x + 97, y + 6, x + 189, y + 18, this.hovered(mouseX, mouseY) ? -13421773 : -14540254);
      drawContext.method_25303(textRenderer, this.elements[this.index], x + 98, y + 8, 16777215);
   }

   @Override
   public void mouseClicked(double mouseX, double mouseY, int button) {
      if (this.hovered((int)mouseX, (int)mouseY) && button == 0) {
         if (this.index >= this.elements.length - 1) {
            this.index = 0;
         } else {
            this.index++;
         }
      }
   }
}
