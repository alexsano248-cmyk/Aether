package net.aether.aether.ui.hud;

import java.util.ArrayList;
import net.aether.aether.module.settings.Setting;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public abstract class HUDModule {
   public int x;
   public int y;
   public int height;
   public int width;
   public String name;
   int startX;
   int startY;
   boolean dragging = false;
   public boolean enabled = false;
   public ArrayList<Setting> settings;
   protected static class_310 mc = class_310.method_1551();

   public HUDModule(String name, int x, int y) {
      this.name = name;
      this.x = x;
      this.y = y;
      this.settings = new ArrayList<>();
   }

   public void render(class_332 drawContext, int mouseX, int mouseY, class_327 textRenderer, boolean editMode, boolean enabled) {
      if (editMode) {
         if (this.dragging) {
            this.x = mouseX - this.startX;
            this.y = mouseY - this.startY;
         }

         drawContext.method_25294(this.x - 1, this.y - 1, this.x + this.width + 1, this.y + this.height + 1, enabled ? -11141121 : -11184811);
         drawContext.method_25294(this.x, this.y, this.x + this.width, this.y + this.height, -14540254);
      }
   }

   public boolean hovered(int mouseX, int mouseY) {
      return mouseX >= this.x && mouseX <= this.x + this.width && mouseY >= this.y && mouseY <= this.y + this.height;
   }

   public void mouseClicked(int mouseX, int mouseY, int button) {
      if (this.hovered(mouseX, mouseY) && button == 0) {
         this.startX = mouseX - this.x;
         this.startY = mouseY - this.y;
         this.dragging = true;
      }
   }

   public void mouseReleased(int mouseX, int mouseY, int button) {
      this.dragging = false;
   }

   public void toggle() {
      this.enabled = !this.enabled;
   }
}
