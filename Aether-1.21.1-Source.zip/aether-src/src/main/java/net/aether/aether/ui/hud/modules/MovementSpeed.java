package net.aether.aether.ui.hud.modules;

import net.aether.aether.ui.hud.HUDModule;
import net.aether.aether.util.ColorUtils;
import net.aether.aether.util.MathUtils;
import net.minecraft.class_243;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class MovementSpeed extends HUDModule {
   public MovementSpeed(int x, int y) {
      super("Movement Speed", x, y);
      this.width = 72;
      this.height = 8;
      this.enabled = true;
   }

   @Override
   public void render(class_332 drawContext, int mouseX, int mouseY, class_327 textRenderer, boolean editMode, boolean enabled) {
      super.render(drawContext, mouseX, mouseY, textRenderer, editMode, enabled);
      drawContext.method_25303(
         mc.field_1772, ColorUtils.aqua + "Meters/s: " + ColorUtils.white + MathUtils.round(this.moveSpeed(), 2), this.x, this.y, -11141121
      );
   }

   private double moveSpeed() {
      class_243 move = new class_243(mc.field_1724.method_23317() - mc.field_1724.field_6014, 0.0, mc.field_1724.method_23321() - mc.field_1724.field_5969)
         .method_1021(20.0);
      return Math.abs(MathUtils.length2D(move));
   }
}
