package net.aether.aether.ui.hud.editor;

import net.aether.aether.ui.hud.HUDModule;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class HUDModuleButton {
   public HUDModule module;
   public int x;
   public int y;
   public int width;
   public int height = 0;

   public HUDModuleButton(HUDModule module) {
      this.module = module;
      this.width = 124;
      this.height = 12;
   }

   public void render(class_332 drawContext, int mouseX, int mouseY, int x, int y, class_327 textRenderer) {
      this.x = x;
      this.y = y;
      drawContext.method_25294(x, y, x + this.width, y + this.height, this.hovered(mouseX, mouseY) ? -13421773 : -14540254);
      drawContext.method_51433(textRenderer, this.module.name, x + 2, y + 2, this.module.enabled ? 5636095 : 16777215, false);
      if (!this.module.settings.isEmpty()) {
         drawContext.method_52706(class_2960.method_60655("aether", "settings"), x + this.width - 12, y, 12, 12);
      }
   }

   public boolean hovered(int mouseX, int mouseY) {
      return mouseX >= this.x && mouseX <= this.x + this.width && mouseY >= this.y && mouseY <= this.y + this.height;
   }

   public boolean mouseClicked(int mouseX, int mouseY, int button) {
      if (this.hovered(mouseX, mouseY)) {
         if (button == 0) {
            this.module.toggle();
         } else if (button == 1 && !this.module.settings.isEmpty()) {
            class_310.method_1551().method_1507(new HUDModuleSettingsScreen(this.module));
         }

         return true;
      } else {
         return false;
      }
   }
}
