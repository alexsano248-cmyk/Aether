package net.aether.aether.ui.hud.modules;

import net.aether.aether.ui.hud.HUDModule;
import net.minecraft.class_1799;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class ArmorDisplay extends HUDModule {
   public ArmorDisplay(int x, int y) {
      super("Armor Display", x, y);
      this.width = 16;
      this.height = 64;
   }

   @Override
   public void render(class_332 drawContext, int mouseX, int mouseY, class_327 textRenderer, boolean editMode, boolean enabled) {
      super.render(drawContext, mouseX, mouseY, textRenderer, editMode, enabled);
      int yOffset = 0;

      for (int i = 39; i >= 36; i--) {
         class_1799 piece = mc.field_1724.method_31548().method_5438(i);
         drawContext.method_51427(piece, this.x, this.y + yOffset);
         drawContext.method_51431(textRenderer, piece, this.x, this.y + yOffset);
         yOffset += 16;
      }
   }
}
