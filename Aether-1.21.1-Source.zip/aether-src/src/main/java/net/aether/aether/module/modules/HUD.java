package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.BooleanSetting;
import net.aether.aether.module.settings.IndexSetting;

public class HUD extends Module {
   public IndexSetting mode = new IndexSetting("Mode", 0, "Modular", "Legacy");
   public BooleanSetting mainmenuhud = new BooleanSetting("Main Menu Client Tag", true);
   public static boolean isSettingEnabled;

   public HUD() {
      super("HUD", "The Aether HUD.", Category.RENDER, false);
      this.enabled = true;
      this.showInModulesList.value = false;
      this.showEditButton = true;
      this.settings.add(this.mode);
      this.settings.add(this.mainmenuhud);
      if (this.mainmenuhud.value) {
         isSettingEnabled = true;
      } else {
         isSettingEnabled = false;
      }
   }
}
