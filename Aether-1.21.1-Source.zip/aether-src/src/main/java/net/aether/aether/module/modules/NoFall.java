package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.minecraft.class_2828.class_5911;

public class NoFall extends Module {
   public NoFall() {
      super("NoFall", "Prevents you from taking fall damage.", Category.PLAYER, true);
   }

   @Override
   public void tick() {
      if ((double)mc.field_1724.field_6017 >= 2.5) {
         mc.field_1724.field_3944.method_52787(new class_5911(true));
      }
   }
}
