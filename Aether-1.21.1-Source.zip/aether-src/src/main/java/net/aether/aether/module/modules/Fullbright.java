package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.util.ISimpleOption;

public class Fullbright extends Module {
   public Fullbright() {
      super("Fullbright", "Allows you to see in the dark.", Category.RENDER, false);
   }

   @Override
   public void onEnable() {
      super.onEnable();
      ((ISimpleOption)mc.field_1690.method_42473()).setValueUnrestricted(100.0);
   }

   @Override
   public void onDisable() {
      super.onDisable();
      mc.field_1690.method_42473().method_41748(1.0);
   }
}
