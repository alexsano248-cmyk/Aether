package net.aether.aether.command.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.aether.aether.command.Command;
import net.aether.aether.module.ModuleManager;
import net.aether.aether.util.ChatUtils;
import net.minecraft.class_2172;

public class Mode extends Command {
   public Mode() {
      super("mode", "Toggle legit mode or blatant mode.");
   }

   @Override
   public void build(LiteralArgumentBuilder<class_2172> builder) {
      ((LiteralArgumentBuilder)builder.then(literal("legit").executes(context -> {
         ModuleManager.blatantMode = false;
         ChatUtils.sendMsg("Switched to §9Legit§f mode");
         return 1;
      }))).then(literal("blatant").executes(context -> {
         ModuleManager.blatantMode = true;
         ChatUtils.sendMsg("Switched to §cBlatant§f mode");
         return 1;
      }));
   }
}
