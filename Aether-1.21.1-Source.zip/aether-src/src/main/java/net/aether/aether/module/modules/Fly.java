package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.DoubleSetting;
import net.aether.aether.module.settings.DropdownSetting;
import net.minecraft.class_1657;
import org.lwjgl.glfw.GLFW;

public class Fly extends Module {
   public final DropdownSetting mode = new DropdownSetting("Mode", "Velocity", new String[]{"Velocity", "Creative"});
   private final DoubleSetting flySpeed = new DoubleSetting("Fly Speed", 1.0, 0.1, 5.0, 1);
   private boolean isFlying;

   public Fly() {
      super("Fly", "Allows you to fly in the air.", Category.MOVEMENT, true);
      this.settings.add(this.flySpeed);
      this.settings.add(this.mode);
   }

   @Override
   public void onEnable() {
      super.onEnable();
      this.isFlying = true;
      if (mc.field_1724 != null) {
         mc.field_1724.method_24830(false);
      }
   }

   @Override
   public void onDisable() {
      super.onDisable();
      this.isFlying = false;
      if (mc.field_1724 != null) {
         mc.field_1724.method_18800(0.0, 0.0, 0.0);
         mc.field_1724.method_31549().field_7479 = false;
      }
   }

   @Override
   public void tick() {
      class_1657 player = mc.field_1724;
      if (player != null && this.isFlying) {
         if (this.mode.value.equals("Creative")) {
            mc.field_1724.method_31549().field_7479 = true;
         } else {
            mc.field_1724.method_31549().field_7479 = false;
            double speed = this.flySpeed.value;
            double yawRad = Math.toRadians((double)player.method_36454());
            double forward = 0.0;
            double right = 0.0;
            if (GLFW.glfwGetKey(mc.method_22683().method_4490(), 87) == 1) {
               forward++;
            }

            if (GLFW.glfwGetKey(mc.method_22683().method_4490(), 83) == 1) {
               forward--;
            }

            if (GLFW.glfwGetKey(mc.method_22683().method_4490(), 68) == 1) {
               right--;
            }

            if (GLFW.glfwGetKey(mc.method_22683().method_4490(), 65) == 1) {
               right++;
            }

            double x = -Math.sin(yawRad) * forward + Math.cos(yawRad) * right;
            double z = Math.cos(yawRad) * forward + Math.sin(yawRad) * right;
            double y = (GLFW.glfwGetKey(mc.method_22683().method_4490(), 32) == 1 ? 1.0 : 0.0)
               - (GLFW.glfwGetKey(mc.method_22683().method_4490(), 340) == 1 ? 1.0 : 0.0);
            x *= speed;
            y *= speed;
            z *= speed;
            player.method_18800(x, y, z);
            player.method_24830(false);
         }
      }
   }
}
