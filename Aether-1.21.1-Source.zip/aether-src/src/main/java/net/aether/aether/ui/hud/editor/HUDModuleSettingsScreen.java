package net.aether.aether.ui.hud.editor;

import net.aether.aether.module.settings.Setting;
import net.aether.aether.ui.SetScreenButton;
import net.aether.aether.ui.hud.HUDModule;
import net.aether.aether.util.ColorUtils;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class HUDModuleSettingsScreen extends class_437 {
   private HUDModule module;
   private SetScreenButton backButton;
   boolean dragging = false;
   int startX;
   int startY;
   int x = HUDEditorScreen.INSTANCE.field_22789 / 2 - 112;
   int y = HUDEditorScreen.INSTANCE.field_22790 / 2 - 96;
   int windowWidth = 224;
   int windowHeight = 192;

   public HUDModuleSettingsScreen(HUDModule module) {
      super(class_2561.method_43470("Settings"));
      this.backButton = new SetScreenButton(ColorUtils.underline + "< Back", this.x + 4, this.y + 4, 16777215, HUDEditorScreen.INSTANCE);
      this.module = module;
   }

   public void method_25394(class_332 drawContext, int mouseX, int mouseY, float delta) {
      this.method_25420(drawContext, mouseX, mouseY, delta);
      if (this.dragging) {
         this.x = mouseX - this.startX;
         this.y = mouseY - this.startY;
      }

      drawContext.method_25294(this.x, this.y, this.x + this.windowWidth, this.y + this.windowHeight, -14540254);
      drawContext.method_25294(this.x, this.y, this.x + this.windowWidth, this.y + 16, -11141121);
      drawContext.method_25294(this.x + 2, this.y + 2, this.x + (this.windowWidth - 2), this.y + 14, -14540254);
      drawContext.method_25300(this.field_22793, this.module.name, this.x + this.windowWidth / 2, this.y + 4, 16777215);
      this.backButton.render(drawContext, this.field_22793, mouseX, mouseY, this.x + 4, this.y + 4);
      int yOffset = this.y + 24;

      for (Setting setting : this.module.settings) {
         setting.render(drawContext, this.x + 16, yOffset, mouseX, mouseY, this.field_22793);
         yOffset += 25;
      }
   }

   public boolean barHovered(int mouseX, int mouseY) {
      return mouseX >= this.x && mouseX <= this.x + this.field_22789 && mouseY >= this.y && mouseY <= this.y + 16;
   }

   public boolean method_25421() {
      return false;
   }

   public boolean method_25402(double mouseX, double mouseY, int button) {
      if (this.barHovered((int)mouseX, (int)mouseY)) {
         this.startX = (int)mouseX - this.x;
         this.startY = (int)mouseY - this.y;
         this.dragging = true;
      }

      this.backButton.mouseClicked((int)mouseX, (int)mouseY);

      for (Setting setting : this.module.settings) {
         setting.mouseClicked(mouseX, mouseY, button);
      }

      return super.method_25402(mouseX, mouseY, button);
   }

   public boolean method_25406(double mouseX, double mouseY, int button) {
      this.dragging = false;

      for (Setting setting : this.module.settings) {
         setting.mouseReleased(mouseX, mouseY, button);
      }

      return super.method_25406(mouseX, mouseY, button);
   }

   public boolean method_25404(int keyCode, int scanCode, int modifiers) {
      for (Setting setting : this.module.settings) {
         setting.keyPressed(keyCode, scanCode, modifiers);
      }

      return super.method_25404(keyCode, scanCode, modifiers);
   }
}
