package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;
import net.aether.aether.module.settings.DoubleSetting;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public class AutoSoup extends Module {
   public final DoubleSetting healthAt = new DoubleSetting("Eat At HP", 14.0, 1.0, 20.0, 0);

   public AutoSoup() {
      super("AutoSoup", "Right-clicks soup/food when low HP.", Category.PLAYER, true);
      this.settings.add(this.healthAt);
   }

   @Override
   public void tick() {
      if (mc.field_1724 == null || mc.field_1761 == null) return;
      if (mc.field_1724.method_6032() > this.healthAt.value) return;
      // Find soup or eatable food in hotbar
      for (int i = 0; i < 9; i++) {
         class_1799 s = mc.field_1724.method_31548().method_5438(i);
         if (s.method_7960()) continue;
         if (s.method_7909() == class_1802.field_8208 || s.method_7909() == class_1802.field_8463 || s.method_31573(net.minecraft.class_3489.field_42612)) {
            int old = mc.field_1724.method_31548().field_7545;
            mc.field_1724.method_31548().field_7545 = i;
            mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
            mc.field_1724.method_31548().field_7545 = old;
            break;
         }
      }
   }
}
