package net.aether.aether.module;

import java.util.ArrayList;
import net.aether.aether.module.modules.Airjump;
import net.aether.aether.module.modules.Airplace;
import net.aether.aether.module.modules.Airwalk;
import net.aether.aether.module.modules.AutoAFK;
import net.aether.aether.module.modules.AutoHitCrystal;
import net.aether.aether.module.modules.AutoJReset;
import net.aether.aether.module.modules.AutoRekit;
import net.aether.aether.module.modules.AutoRespawn;
import net.aether.aether.module.modules.AutoTotem;
import net.aether.aether.module.modules.Cape;
import net.aether.aether.module.modules.ChatSpammer;
import net.aether.aether.module.modules.FPSSpoofer;
import net.aether.aether.module.modules.FastMine;
import net.aether.aether.module.modules.FastPlace;
import net.aether.aether.module.modules.Fly;
import net.aether.aether.module.modules.Fullbright;
import net.aether.aether.module.modules.HUD;
import net.aether.aether.module.modules.MaceBoost;
import net.aether.aether.module.modules.ArrayList;
import net.aether.aether.module.modules.NoFall;
import net.aether.aether.module.modules.NoJumpDelay;
import net.aether.aether.module.modules.QuickFall;
import net.aether.aether.module.modules.Reach;
import net.aether.aether.module.modules.Speed;
import net.aether.aether.module.modules.Sprint;
import net.aether.aether.module.modules.Step;
import net.aether.aether.module.modules.Triggerbot;
import net.aether.aether.module.modules.Velocity;

import net.aether.aether.module.modules.KillAura;
import net.aether.aether.module.modules.Scaffold;
import net.aether.aether.module.modules.LagRange;
import net.aether.aether.module.modules.AutoRecraft;
import net.aether.aether.module.modules.AutoSoup;
import net.aether.aether.module.modules.Camera;
import net.aether.aether.module.modules.BowAimbot;
import net.aether.aether.module.modules.ChinaHat;
import net.aether.aether.module.modules.Watermark;
import net.aether.aether.module.modules.TargetHUD;

public class ModuleManager {
   public static ModuleManager INSTANCE = new ModuleManager();
   public ArrayList<Module> modules = new ArrayList<>();
   public static boolean blatantMode = true;

   public ModuleManager() {
      this.registerModules(
         new Fly(),
         new NoFall(),
         new HUD(),
         new Step(),
         new Fullbright(),
         new Speed(),
         new ArrayList(),
         new ChatSpammer(),
         new Reach(),
         new AutoTotem(),
         new NoJumpDelay(),
         new Sprint(),
         new Airplace(),
         new FastPlace(),
         new QuickFall(),
         new MaceBoost(),
         new FastMine(),
         new Cape(),
         new Airjump(),
         new Triggerbot(),
         new FPSSpoofer(),
         new Airwalk(),
         new AutoAFK(),
         new AutoRespawn(),
         new AutoRekit(),
         new Velocity(),
         new AutoJReset(),
         new AutoHitCrystal(),
         new KillAura(),
         new Scaffold(),
         new LagRange(),
         new AutoRecraft(),
         new AutoSoup(),
         new Camera(),
         new BowAimbot(),
         new ChinaHat(),
         new Watermark(),
         new TargetHUD()
      );
   }

   public static boolean isBlatantMode() {
      return blatantMode;
   }

   public static void toggleBlatantMode() {
      blatantMode = !blatantMode;
   }

   private void registerModules(Module... modules) {
      for (Module module : modules) {
         this.modules.add(module);
      }
   }

   public Module getModuleByName(String moduleName) {
      for (Module module : this.modules) {
         if (module.name.trim().equalsIgnoreCase(moduleName)) {
            return module;
         }
      }

      return null;
   }

   public ArrayList<Module> getModulesByCategory(Category category) {
      ArrayList<Module> returnedModules = new ArrayList<>();

      for (Module module : this.modules) {
         if (module.category == category) {
            returnedModules.add(module);
         }
      }

      return returnedModules;
   }

   public ArrayList<Module> getEnabledModules() {
      ArrayList<Module> enabledModules = new ArrayList<>();

      for (Module module : this.modules) {
         if (module.enabled) {
            enabledModules.add(module);
         }
      }

      return enabledModules;
   }
}
