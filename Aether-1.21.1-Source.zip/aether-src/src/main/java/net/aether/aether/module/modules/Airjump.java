package net.aether.aether.module.modules;

import net.aether.aether.module.Category;
import net.aether.aether.module.Module;

public class Airjump extends Module {
   public Airjump() {
      super("Airjump", "Jump in the air!", Category.MOVEMENT, true);
   }

   @Override
   public void onEnable() {
      super.onEnable();
      mc.field_1724.method_24830(true);
   }

   @Override
   public void onDisable() {
      super.onDisable();
      mc.field_1724.method_24830(false);
   }

   @Override
   public void tick() {
      mc.field_1724.method_24830(true);
   }
}
