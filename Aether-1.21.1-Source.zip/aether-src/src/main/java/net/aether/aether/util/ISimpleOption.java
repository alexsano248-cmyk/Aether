package net.aether.aether.util;

public interface ISimpleOption<T> {
   void setValueUnrestricted(T var1);
}
