package net.aether.aether.ui;

import net.aether.aether.Aether;
import net.aether.aether.util.ColorUtils;
import net.aether.aether.util.MathUtils;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class LegacyHUD {
   public static LegacyHUD INSTANCE = new LegacyHUD();
   private class_310 mc = class_310.method_1551();

   public void render(class_332 drawContext, int scaledWidth, int scaledHeight) {
      if (!this.mc.method_53526().method_53536()) {
         drawContext.method_25303(this.mc.field_1772, "FPS: " + ColorUtils.gray + this.mc.field_1770.split(" ")[0], 2, 2, -11141121);
         drawContext.method_25303(
            this.mc.field_1772,
            "Ping: "
               + ColorUtils.gray
               + (
                  this.mc.method_1562().method_2871(this.mc.field_1724.method_5667()) == null
                     ? 0
                     : this.mc.method_1562().method_2871(this.mc.field_1724.method_5667()).method_2959()
               ),
            2,
            12,
            -11141121
         );
         drawContext.method_25303(this.mc.field_1772, "Meters/s: " + ColorUtils.gray + MathUtils.round(this.moveSpeed(), 2), 2, scaledHeight - 20, -11141121);
         drawContext.method_25303(
            this.mc.field_1772,
            "X: "
               + ColorUtils.gray
               + String.format("%.1f", this.mc.field_1724.method_23317())
               + ColorUtils.reset
               + " Y: "
               + ColorUtils.gray
               + String.format("%.1f", this.mc.field_1724.method_23318())
               + ColorUtils.reset
               + " Z: "
               + ColorUtils.gray
               + String.format("%.1f", this.mc.field_1724.method_23321()),
            2,
            scaledHeight - 10,
            -11141121
         );
         drawContext.method_25303(
            this.mc.field_1772,
            Aether.clientTag + " " + Aether.versionTag,
            scaledWidth - this.mc.field_1772.method_1727(Aether.clientTag + " " + Aether.versionTag) - 2,
            scaledHeight - 10,
            16777215
         );
      }
   }

   private double moveSpeed() {
      class_243 move = new class_243(
            this.mc.field_1724.method_23317() - this.mc.field_1724.field_6014, 0.0, this.mc.field_1724.method_23321() - this.mc.field_1724.field_5969
         )
         .method_1021(20.0);
      return Math.abs(MathUtils.length2D(move));
   }
}
